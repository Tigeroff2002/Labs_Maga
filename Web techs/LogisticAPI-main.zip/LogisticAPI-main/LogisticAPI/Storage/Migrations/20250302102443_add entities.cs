﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Models.Account;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Storage.Migrations
{
    /// <inheritdoc />
    public partial class addentities : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterDatabase()
                .Annotation("Npgsql:Enum:role", "user,admin");

            migrationBuilder.CreateTable(
                name: "segments",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    start_width = table.Column<double>(type: "double precision", nullable: false),
                    start_height = table.Column<double>(type: "double precision", nullable: false),
                    end_width = table.Column<double>(type: "double precision", nullable: false),
                    end_height = table.Column<double>(type: "double precision", nullable: false),
                    sequence_number = table.Column<int>(type: "integer", nullable: false),
                    length = table.Column<double>(type: "double precision", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_segments", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "users",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    email = table.Column<string>(type: "text", nullable: false),
                    role = table.Column<Role>(type: "role", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_users", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "requests",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                    guid = table.Column<string>(type: "text", nullable: false),
                    user_id = table.Column<long>(type: "bigint", nullable: false),
                    start_width = table.Column<double>(type: "double precision", nullable: false),
                    start_height = table.Column<double>(type: "double precision", nullable: false),
                    end_width = table.Column<double>(type: "double precision", nullable: false),
                    end_height = table.Column<double>(type: "double precision", nullable: false),
                    creation_date = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    last_update = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_requests", x => x.id);
                    table.ForeignKey(
                        name: "fk_requests_users_user_id",
                        column: x => x.user_id,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "active_segments",
                columns: table => new
                {
                    segment_id = table.Column<long>(type: "bigint", nullable: false),
                    request_id = table.Column<long>(type: "bigint", nullable: false),
                    last_update = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_active_segments", x => new { x.segment_id, x.request_id });
                    table.ForeignKey(
                        name: "fk_active_segments_requests_request_id",
                        column: x => x.request_id,
                        principalTable: "requests",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_active_segments_segments_segment_id",
                        column: x => x.segment_id,
                        principalTable: "segments",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "initial_segments",
                columns: table => new
                {
                    segment_id = table.Column<long>(type: "bigint", nullable: false),
                    request_id = table.Column<long>(type: "bigint", nullable: false),
                    generation_time = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_initial_segments", x => new { x.segment_id, x.request_id });
                    table.ForeignKey(
                        name: "fk_initial_segments_requests_request_id",
                        column: x => x.request_id,
                        principalTable: "requests",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_initial_segments_segments_segment_id",
                        column: x => x.segment_id,
                        principalTable: "segments",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "ix_active_segments_request_id",
                table: "active_segments",
                column: "request_id");

            migrationBuilder.CreateIndex(
                name: "ix_active_segments_segment_id",
                table: "active_segments",
                column: "segment_id",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_initial_segments_request_id",
                table: "initial_segments",
                column: "request_id");

            migrationBuilder.CreateIndex(
                name: "ix_initial_segments_segment_id",
                table: "initial_segments",
                column: "segment_id",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ix_requests_user_id",
                table: "requests",
                column: "user_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "active_segments");

            migrationBuilder.DropTable(
                name: "initial_segments");

            migrationBuilder.DropTable(
                name: "requests");

            migrationBuilder.DropTable(
                name: "segments");

            migrationBuilder.DropTable(
                name: "users");
        }
    }
}
