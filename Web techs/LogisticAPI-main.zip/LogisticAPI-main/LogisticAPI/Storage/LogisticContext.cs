﻿using Microsoft.EntityFrameworkCore;
using Models;
using Models.Account;
using Npgsql;
using Storage.Models;

using RequestStatus = Models.Requests.RequestStatus;
using SegmentType = Models.Segments.SegmentType;
using PaymentStatus = Models.Payments.PaymentStatus;

using User = Storage.Models.User;

namespace Storage;

public sealed class LogisticContext : DbContext
{
    public DbSet<User> Users { get; set; } = null!;

    public DbSet<Request> Requests { get; set; } = null!;

    public DbSet<Segment> Segments { get; set; } = null!;

    public DbSet<Payment> Payments { get; set; } = null!;

    public DbSet<Subscription> Subscriptions { get; set; } = null!;

    [Obsolete]
    static LogisticContext()
        => NpgsqlConnection.GlobalTypeMapper
            .MapEnum<Role>()
            .MapEnum<RequestStatus>()
            .MapEnum<RequestType>()
            .MapEnum<SegmentType>()
            .MapEnum<PaymentStatus>();

    public LogisticContext(DbContextOptions<LogisticContext> options)
        : base(options)
    {

    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
       => optionsBuilder
            .UseSnakeCaseNamingConvention()
            .UseNpgsql(x => x
                .MapEnum<Role>("role")
                .MapEnum<RequestStatus>("request_status")
                .MapEnum<RequestType>("request_type")
                .MapEnum<SegmentType>("segment_type")
                .MapEnum<PaymentStatus>("payment_status"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        _ = modelBuilder
            .HasPostgresEnum<Role>(name: "role")
            .HasPostgresEnum<RequestStatus>(name: "request_status")
            .HasPostgresEnum<RequestType>(name: "request_type")
            .HasPostgresEnum<SegmentType>(name: "segment_type");

        ConfigureUsers(modelBuilder);
        ConfigureRequests(modelBuilder);
        ConfigureSegments(modelBuilder);
        ConfigurePayments(modelBuilder);
        ConfigureSubscriptions(modelBuilder);

        base.OnModelCreating(modelBuilder);
    }

    private static void ConfigureUsers(ModelBuilder modelBuilder)
    {
        _ = modelBuilder.Entity<User>()
            .HasKey(x => x.Id);

        _ = modelBuilder.Entity<User>()
            .Property(x => x.Id)
            .UseIdentityAlwaysColumn();

        _ = modelBuilder.Entity<User>()
            .ToTable("users");

        _ = modelBuilder.Entity<User>()
            .HasMany(x => x.Requests)
            .WithOne(x => x.User)
            .HasForeignKey(x => x.UserId);

        _ = modelBuilder.Entity<User>()
            .HasMany(x => x.Subscriptions)
            .WithOne(x => x.User)
            .HasForeignKey(x => x.UserId);
    }

    private static void ConfigureRequests(ModelBuilder modelBuilder)
    {
        _ = modelBuilder.Entity<Request>()
            .HasKey(x => x.Id);

        _ = modelBuilder.Entity<Request>()
            .Property(x => x.Id)
            .UseIdentityAlwaysColumn();

        _ = modelBuilder.Entity<Request>()
            .ToTable("requests");

        _ = modelBuilder.Entity<Request>()
            .HasOne(x => x.User)
            .WithMany(x => x.Requests)
            .HasForeignKey(x => x.UserId);

        _ = modelBuilder.Entity<Request>()
            .HasMany(x => x.Segments)
            .WithOne(x => x.Request)
            .HasForeignKey(x => x.RequestId);
    }

    private static void ConfigureSegments(ModelBuilder modelBuilder)
    {
        _ = modelBuilder.Entity<Segment>()
            .HasKey(x => x.Id);

        _ = modelBuilder.Entity<Segment>()
            .Property(x => x.Id)
            .UseIdentityAlwaysColumn();

        _ = modelBuilder.Entity<Segment>()
            .ToTable("segments");

        _ = modelBuilder.Entity<Segment>()
            .HasOne(x => x.Request)
            .WithMany(x => x.Segments)
            .HasForeignKey(x => x.RequestId);
    }

    private static void ConfigurePayments(ModelBuilder modelBuilder)
    {
        _ = modelBuilder.Entity<Payment>()
            .HasKey(x => x.Id);

        _ = modelBuilder.Entity<Payment>()
            .Property(x => x.Id)
            .UseIdentityAlwaysColumn();

        _ = modelBuilder.Entity<Payment>()
            .ToTable("payments");

        _ = modelBuilder.Entity<Payment>()
            .HasOne(x => x.User)
            .WithMany(x => x.Payments)
            .HasForeignKey(x => x.UserId);

        _ = modelBuilder.Entity<Payment>()
            .HasOne(x => x.Subscription)
            .WithOne(x => x.Payment)
            .HasForeignKey<Subscription>(x => x.PaymentId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Restrict);
    }

    private static void ConfigureSubscriptions(ModelBuilder modelBuilder)
    {
        _ = modelBuilder.Entity<Subscription>()
            .HasKey(x => x.Id);

        _ = modelBuilder.Entity<Subscription>()
            .Property(x => x.Id)
            .UseIdentityAlwaysColumn();

        _ = modelBuilder.Entity<Subscription>()
            .ToTable("subscriptions");

        _ = modelBuilder.Entity<Subscription>()
            .HasOne(x => x.User)
            .WithMany(x => x.Subscriptions)
            .HasForeignKey(x => x.UserId);

        _ = modelBuilder.Entity<Subscription>()
            .HasOne(x => x.Payment)
            .WithOne(x => x.Subscription)
            .HasForeignKey<Subscription>(x => x.PaymentId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Restrict);
    }
}