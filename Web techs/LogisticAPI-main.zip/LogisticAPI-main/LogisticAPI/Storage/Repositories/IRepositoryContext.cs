﻿using Microsoft.EntityFrameworkCore;
using Storage.Models;

namespace Storage.Repositories;

public interface IRepositoryContext
{
    DbSet<User> Users { get; }

    DbSet<Request> Requests { get; }

    DbSet<Segment> Segments { get; }

    DbSet<Payment> Payments { get; }

    DbSet<Subscription> Subscriptions { get; }
}
