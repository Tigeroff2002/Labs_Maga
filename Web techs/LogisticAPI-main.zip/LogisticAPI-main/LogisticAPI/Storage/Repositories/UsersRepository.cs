﻿using System.Net.Mail;
using Abstractions.Storage.Repositories;
using Microsoft.EntityFrameworkCore;
using Models.Account;
using Models;

namespace Storage.Repositories;

public sealed class UsersRepository :
    RepositoryBase,
    IUsersRepository
{
    public UsersRepository(IRepositoryContext context) : base(context)
    {
    }

    public async Task AddUserAsync(
        RegisteringUser user,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(user);

        var address = user.Email.Address;

        if (await Context.Users
            .AsNoTracking()
            .SingleOrDefaultAsync(
                x => x.Email == address,
                token) is not null)
        {
            throw new InvalidOperationException(
                $"User with email {address} already exists.");
        }

        Context.Users.Add(new()
        {
            Email = address,
            Role = user.Role
        });
    }

    public async Task<UserProfileInfo?> FindUserProfileInfoByEmailAsync(
        MailAddress mailAddress,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(mailAddress);

        var existedUser = await Context.Users
            .AsNoTracking()
            .SingleOrDefaultAsync(
                x => x.Email == mailAddress.Address,
                token);

        return existedUser is not null
            ? new(
                new(existedUser.Id),
                mailAddress,
                existedUser.Role)
            : null;
    }

    public async Task<UserProfileInfo> GetUserProfileInfoByIdAsync(
        Id<User> userId,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(userId);

        var existedUser = await Context.Users
            .AsNoTracking()
            .SingleOrDefaultAsync(
                x => x.Id == userId.Value,
                token);

        if (existedUser is null)
        {
            throw new InvalidOperationException(
                $"User with id {userId.Value} not already exists.");
        }

        return new(
            new(existedUser.Id),
            new(existedUser.Email),
            existedUser.Role);
    }

    public async Task<Role> GetUserRoleAsync(
        Id<User> userId,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(userId);

        var existedUser = await Context.Users
            .AsNoTracking()
            .SingleOrDefaultAsync(
                x => x.Id == userId.Value,
                token);

        if (existedUser is null)
        {
            throw new InvalidOperationException(
                $"User with id {userId.Value} not already exists.");
        }

        return existedUser.Role;
    }
}