﻿using Abstractions.Storage.Repositories;
using Microsoft.EntityFrameworkCore;
using Models;
using Models.Account;
using Models.Payments;
using Models.Subscriptions;

namespace Storage.Repositories;

public sealed class SubscriptionsRepository :
    RepositoryBase,
    ISubscriptionsRepository
{
    public SubscriptionsRepository(IRepositoryContext context) 
        : base(context)
    {
    }

    public async Task AddSubscriptionAsync(
        AddingSubscription subscription, 
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(subscription);

        var userId = subscription.UserId.Value;

        var relatedUser = await Context.Users.FindAsync([userId], token);

        if (relatedUser is null)
        {
            throw new InvalidOperationException(
                $"There is not user with id {userId}.");
        }

        var paymentId = subscription.PaymentId.Value;

        var relatedPayment = await Context.Payments.FindAsync([paymentId], token);

        if (relatedPayment is null)
        {
            throw new InvalidOperationException(
                $"There is not created payment with id {paymentId}.");
        }

        if (relatedPayment.Status != PaymentStatus.Succeeded
            || relatedPayment.Status != PaymentStatus.WaitingForCapture)
        {
            throw new InvalidOperationException(
                $"There is not already succeeded payment with id {paymentId}.");
        }

        var now = DateTimeOffset.UtcNow;

        var existedSubscriptions = await Context.Subscriptions
            .Where(x => x.UserId == userId && x.EndDate > now)
            .ToListAsync(token);

        if (existedSubscriptions.Any())
        {
            throw new InvalidOperationException(
                $"For user {userId} existed active subscription.");
        }

        Context.Subscriptions.Add(new()
        {
            UserId = userId,
            PaymentId = paymentId,
            StartDate = now,
            EndDate = now.Add(subscription.Duration)
        });
    }

    public async Task<Subscription?> FindActiveUserSubscriptionAsync(
        Id<User> userId,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(userId);

        var now = DateTimeOffset.UtcNow;

        var activeSubscription = await Context.Subscriptions
            .OrderBy(x => x.Id)
            .FirstOrDefaultAsync(x => x.UserId == userId.Value && x.EndDate > now);

        return activeSubscription is null
            ? null
            : new(
                userId,
                new(activeSubscription.PaymentId),
                activeSubscription.StartDate,
                activeSubscription.EndDate);
    }
}