﻿using Abstractions.Storage.Repositories;
using Microsoft.EntityFrameworkCore;
using Models;
using Models.Account;
using Models.Requests;
using Models.Segments;

using SegmentType = Models.Segments.SegmentType;

namespace Storage.Repositories;

public sealed class RequestsRepository :
    RepositoryBase,
    IRequestsRepository
{
    public RequestsRepository(IRepositoryContext context) : base(context)
    {
    }

    public async Task CreateRequestAsync(
        CreatingRequest request, 
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(request);

        var existedRequest =
            await Context.Requests.SingleOrDefaultAsync(
                x => x.Guid == request.Guid.Value,
                token);

        if (existedRequest is not null)
        {
            throw new InvalidOperationException(
                $"Request with guid: {request.Guid.Value} already exists.");
        }

        var now = DateTimeOffset.UtcNow;

        var contextRequest = new Models.Request()
        {
            UserId = request.UserId.Value,
            Guid = request.Guid.Value,
            Status = RequestStatus.Created,
            RequestType = request.RequestType,
            StartWidth = request.CoordsRange.Start.Width.Value,
            StartHeight = request.CoordsRange.Start.Height.Value,
            EndWidth = request.CoordsRange.End.Width.Value,
            EndHeight = request.CoordsRange.End.Height.Value,
            CreationDate = now,
            LastUpdate = now,
        };

        Context.Requests.Add(contextRequest);

        foreach (var segment in request.Segments)
        {
            Context.Segments.Add(new()
            {
                Request = contextRequest,
                Type = SegmentType.Initial,
                SequenceNumber = segment.Number.Value,
                StartWidth = segment.CoordsRange.Start.Width.Value,
                StartHeight = segment.CoordsRange.Start.Height.Value,
                EndWidth = segment.CoordsRange.End.Width.Value,
                EndHeight = segment.CoordsRange.End.Height.Value,
                Length = segment.Length.Value
            });
        }
    }

    public async Task UpdateRequestActiveSegments(
        Id<Request> requestId,
        IReadOnlyCollection<CreatingSegment> activeSegments,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(requestId);

        var existedRequest =
            await Context.Requests
                .Include(x => x.Segments)
                .SingleOrDefaultAsync(
                    x => x.Id == requestId.Value,
                    token);

        if (existedRequest is null)
        {
            throw new InvalidOperationException(
                $"Request with id {requestId.Value} not already exists.");
        }

        var now = DateTimeOffset.UtcNow;

        var currentActiveSegments =
            existedRequest.Segments.Where(x => x.Type == SegmentType.Active);

        Context.Segments.RemoveRange(currentActiveSegments);

        foreach (var segment in activeSegments)
        {
            Context.Segments.Add(new()
            {
                RequestId = requestId.Value,
                Type = SegmentType.Initial,
                SequenceNumber = segment.Number.Value,
                StartWidth = segment.CoordsRange.Start.Width.Value,
                StartHeight = segment.CoordsRange.Start.Height.Value,
                EndWidth = segment.CoordsRange.End.Width.Value,
                EndHeight = segment.CoordsRange.End.Height.Value,
                Length = segment.Length.Value
            });
        }
    }

    public async Task RecreateRequestAsync(
        RecreatingRequest request,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(request);

        var existedRequest =
            await Context.Requests.SingleOrDefaultAsync(
                x => x.Id == request.RequestId.Value,
                token);

        if (existedRequest is null)
        {
            throw new InvalidOperationException(
                $"Request with id: {request.RequestId.Value} not already exists.");
        }

        if (existedRequest.Status != RequestStatus.Created)
        {
            throw new InvalidOperationException(
                $"Can not recreate request with status '{existedRequest.Status}'.");
        }

        Context.Segments.RemoveRange(existedRequest.Segments);

        var now = DateTimeOffset.UtcNow;

        foreach (var segment in request.InitialSegments)
        {
            Context.Segments.Add(new()
            {
                RequestId = request.RequestId.Value,
                Type = SegmentType.Initial,
                SequenceNumber = segment.Number.Value,
                StartWidth = segment.CoordsRange.Start.Width.Value,
                StartHeight = segment.CoordsRange.Start.Height.Value,
                EndWidth = segment.CoordsRange.End.Width.Value,
                EndHeight = segment.CoordsRange.End.Height.Value,
                Length = segment.Length.Value
            });
        }

        existedRequest.CreationDate = now;
        existedRequest.LastUpdate = now;
    }

    public async Task ChangeRequestStatusAsync(
        ChangeRequestStatus changeModel,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(changeModel);

        var existedRequest =
            await Context.Requests
                .Include(x => x.Segments)
                .SingleOrDefaultAsync(
                    x => x.Id == changeModel.RequestId.Value,
                    token);

        if (existedRequest is null)
        {
            throw new InvalidOperationException(
                $"Request with id: {changeModel.RequestId.Value} not already exists.");
        }

        existedRequest.Status = changeModel.NewStatus;
    }

    public async Task<Request> GetRequestByIdAsync(
        Id<Request> requestId, 
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(requestId);

        var existedRequest =
            await Context.Requests
                .Include(x => x.Segments)
                .SingleOrDefaultAsync(
                    x => x.Id == requestId.Value,
                    token);

        if (existedRequest is null)
        {
            throw new InvalidOperationException(
                $"Request with id: {requestId.Value} not already exists.");
        }

        return new(
            new(existedRequest.Id),
            new(existedRequest.UserId), 
            new(new(
                new(existedRequest.StartWidth), new(existedRequest.StartHeight)), 
                new(new(existedRequest.EndWidth), new(existedRequest.EndHeight))),
            existedRequest.Status,
            existedRequest.RequestType,
            existedRequest.Segments.Select(s => new Segment(
                new(s.Id),
                new(s.RequestId), 
                s.Type,
                new(
                    new(new(s.StartWidth), new(s.StartHeight)),
                    new(new(s.EndWidth), new(s.EndHeight))),
                new(s.Length),
                new(s.SequenceNumber))).ToList(),
            existedRequest.CreationDate);
    }

    public async Task<Id<Request>> GetRequestIdByGuidAsync(
        Name<Request> requestGuid, 
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(requestGuid);

        var existedRequest =
            await Context.Requests.SingleOrDefaultAsync(
                x => x.Guid == requestGuid.Value,
                token);

        if (existedRequest is null)
        {
            throw new InvalidOperationException(
                $"Request with guid: {requestGuid.Value} not already exists.");
        }

        return new(existedRequest.Id);
    }

    public async Task<IReadOnlyCollection<RequestPreview>> GetAllUserRequestsPreviewsAsync(
        Id<User> userId,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(userId);

        var existedUser =
            await Context.Users
                .Include(x => x.Requests)
                .AsNoTracking()
                .SingleOrDefaultAsync(x => x.Id == userId.Value, token);

        if (existedUser is null)
        {
            throw new InvalidOperationException(
                $"User with id {userId.Value} doesnt exist.");
        }

        return existedUser.Requests
            .Select(r => new RequestPreview(
                new(r.Id),
                r.Status,
                r.RequestType,
                r.CreationDate,
                r.LastUpdate))
            .ToList();
    }

    public async Task<bool> IsRequestRelatedToMe(
        Id<Request> requestId,
        Id<User> userId, 
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(requestId);
        ArgumentNullException.ThrowIfNull(userId);

        var existedRequest = 
            await Context.Requests
                .SingleOrDefaultAsync(x => x.Id == requestId.Value, token);

        if (existedRequest is null)
        {
            throw new InvalidOperationException(
                $"Request with id {requestId.Value} doesnt exist.");
        }

        return existedRequest.UserId == userId.Value;
    }
}