﻿namespace Storage.Repositories;

public abstract class RepositoryBase
{
    public IRepositoryContext Context { get; set; }

    public RepositoryBase(IRepositoryContext context)
    {
        Context = context ?? throw new ArgumentNullException(nameof(context));
    }
}
