﻿using System;
using System.ComponentModel;
using Abstractions.Storage.Repositories;
using Microsoft.EntityFrameworkCore;
using Models;
using Models.Payments;

namespace Storage.Repositories;

public sealed class PaymentsRepository :
    RepositoryBase,
    IPaymentsRepository
{
    public PaymentsRepository(IRepositoryContext context) : base(context)
    {
    }

    public async Task AddPaymentTransactionAsync(
        PaymentRequest paymentRequest,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(paymentRequest);

        var guid = paymentRequest.PaymentGuid.Value;

        var existedGuidRequest =
            await Context.Payments
                .AsNoTracking()
                .SingleOrDefaultAsync(x => x.Guid == guid, token);

        if (existedGuidRequest is not null)
        {
            throw new InvalidOperationException(
                $"Already added payment with guid: {guid}.");
        }

        var userId = paymentRequest.UserId.Value;

        var relatedUser = await Context.Users.FindAsync([userId], token);

        if (relatedUser is null)
        {
            throw new InvalidOperationException(
                $"There is not user with id {userId}.");
        }

        var now = DateTimeOffset.UtcNow;

        Context.Payments.Add(new()
        {
            Guid = guid,
            Amount = paymentRequest.Amount.Value,
            UserId = userId,
            Status = PaymentStatus.Pending,
            CreationDate = now,
            LastUpdate = now
        });
    }

    public async Task<Payment> GetPaymentByGuidAsync(
        PaymentGUID paymentGuid,
        CancellationToken token)
    {
        var existedPayment =
            await Context.Payments
                .AsNoTracking()
                .SingleOrDefaultAsync(x => x.Guid == paymentGuid.Value, token);

        if (existedPayment is null)
        {
            throw new InvalidOperationException(
                $"There is no payment with guid: {paymentGuid.Value}.");
        }

        return new(
            new(existedPayment.UserId),
            new(existedPayment.Id),
            paymentGuid, 
            new(existedPayment.Amount),
            existedPayment.CreationDate,
            existedPayment.LastUpdate,
            existedPayment.Status);
    }

    public async Task UpdatePaymentStatusAsync(
        PaymentGUID paymentGuid,
        PaymentStatus newStatus,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(paymentGuid);

        if (!Enum.IsDefined(typeof(PaymentStatus), newStatus))
        {
            throw new InvalidEnumArgumentException(nameof(newStatus));
        }

        var existedPayment =
            await Context.Payments
                .SingleOrDefaultAsync(x => x.Guid == paymentGuid.Value, token);

        if (existedPayment is null)
        {
            throw new InvalidOperationException(
                $"There is no payment with id: {paymentGuid.Value}.");
        }

        existedPayment.Status = newStatus;
    }
}