﻿using Microsoft.EntityFrameworkCore;
using Storage.Models;

namespace Storage.Repositories;

public sealed class RepositoryContext : 
    IRepositoryContext
{
    public DbSet<User> Users => _context.Users;

    public DbSet<Request> Requests => _context.Requests;

    public DbSet<Segment> Segments => _context.Segments;

    public DbSet<Payment> Payments => _context.Payments;

    public DbSet<Subscription> Subscriptions => _context.Subscriptions;

    public RepositoryContext(LogisticContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));  
    }

    private readonly LogisticContext _context;
}