﻿using System.Data;
using Abstractions.Storage;
using Abstractions.Storage.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace Storage;

public sealed class LogisticUnitOfWork :
    ILogisticUnitOfWork
{
    public IUsersRepository Users { get; }

    public IRequestsRepository Requests { get; }

    public IPaymentsRepository Payments { get; }

    public LogisticContext Context { get; }

    public ISubscriptionsRepository Subscriptions { get; }

    public LogisticUnitOfWork(
        IUsersRepository users,
        IRequestsRepository requests,
        IPaymentsRepository payments,
        ISubscriptionsRepository subscriptions,
        LogisticContext context)
    {
        Users = users ?? throw new ArgumentNullException(nameof(users));

        Requests = requests ?? throw new ArgumentNullException(nameof(requests));

        Payments = payments ?? throw new ArgumentNullException(nameof(payments));

        Subscriptions = subscriptions 
            ?? throw new ArgumentNullException(nameof(subscriptions));

        Context = context ?? throw new ArgumentNullException(nameof(context));

        _dbContextTransaction =
            Context.Database.BeginTransaction(IsolationLevel.ReadCommitted);
    }

    public async Task SaveAsync(CancellationToken token)
    {
        await Context.SaveChangesAsync(token);

        await _dbContextTransaction.CommitAsync(token);
    }

    public async ValueTask DisposeAsync() => await _dbContextTransaction.DisposeAsync();

    private readonly IDbContextTransaction _dbContextTransaction;
}