﻿using Models.Account;

namespace Storage.Models;

public sealed class User
{
    public long Id { get; set; }

    public required string Email { get; init; }

    public required Role Role { get; set; }

    public ICollection<Request> Requests { get; set; } = null!;

    public ICollection<Payment> Payments { get; set; } = null!;

    public ICollection<Subscription> Subscriptions { get; set; } = null!;
}