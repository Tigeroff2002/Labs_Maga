﻿using Models;
using Models.Requests;

namespace Storage.Models;

public sealed class Request
{
    public long Id { get; set; }

    public required string Guid { get; init; }

    public required long UserId { get; init; }

    public User User { get; set; } = null!;

    public required RequestStatus Status { get; set; }

    public required RequestType RequestType { get; init; }

    public required double StartWidth { get; init; }

    public required double StartHeight { get; init; }

    public required double EndWidth { get; init; }

    public required double EndHeight { get; init; }

    public required DateTimeOffset CreationDate { get; set; }

    public DateTimeOffset LastUpdate { get; set; } = DateTimeOffset.UtcNow;

    public ICollection<Segment> Segments { get; set; } = null!;
}