﻿namespace Storage.Models;

public sealed class Subscription
{
    public long Id { get; set; }

    public required long PaymentId { get; init; }

    public Payment Payment { get; set; } = null!;

    public required long UserId { get; init; }

    public User User { get; set; } = null!;

    public required DateTimeOffset StartDate { get; init; }

    public required DateTimeOffset EndDate { get; init; }
}