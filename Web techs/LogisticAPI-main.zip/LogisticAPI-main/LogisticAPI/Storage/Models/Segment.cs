﻿using Models.Segments;

namespace Storage.Models;

public sealed class Segment
{
    public long Id { get; set; }

    public long RequestId { get; init; }

    public Request Request { get; set; } = null!;

    public required SegmentType Type { get; init; }

    public required int SequenceNumber { get; init; }

    public required double StartWidth { get; init; }

    public required double StartHeight { get; init; }

    public required double EndWidth { get; init; }

    public required double EndHeight { get; init; }

    public required double Length { get; init; }
}