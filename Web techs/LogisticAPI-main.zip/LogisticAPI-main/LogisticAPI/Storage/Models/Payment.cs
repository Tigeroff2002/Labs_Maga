﻿using Models.Payments;

namespace Storage.Models;

public sealed class Payment
{
    public long Id { get; set; }

    public required string Guid { get; set; }

    public decimal Amount { get; init; }

    public required PaymentStatus Status { get; set; }

    public required DateTimeOffset CreationDate { get; init; }

    public required DateTimeOffset LastUpdate { get; set; }

    public required long UserId { get; init; }

    public User User { get; set; } = null!;

    public Subscription Subscription { get; set; } = null!;
}