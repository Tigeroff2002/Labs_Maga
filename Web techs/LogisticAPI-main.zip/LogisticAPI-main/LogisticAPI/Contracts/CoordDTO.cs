﻿using Newtonsoft.Json;

namespace Contracts;

public sealed class CoordDTO
{
    [JsonProperty("width", Required = Required.Always)]
    public required double Width { get; init; }

    [JsonProperty("heigth", Required = Required.Always)]
    public required double Heigth { get; init; }
}