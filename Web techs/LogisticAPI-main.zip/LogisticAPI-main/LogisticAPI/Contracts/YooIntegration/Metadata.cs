﻿using Newtonsoft.Json;

namespace Contracts.YooIntegration;

public sealed class Metadata
{
    [JsonProperty("orderId", Required = Required.Always)]
    public required string OrderId { get; init; }
}