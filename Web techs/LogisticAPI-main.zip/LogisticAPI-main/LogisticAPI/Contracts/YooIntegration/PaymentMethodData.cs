﻿using Newtonsoft.Json;

namespace Contracts.Integration;

public sealed class PaymentMethodData
{
    [JsonProperty("type", Required = Required.Always)]
    public string Type => "bank_card";  // Указываем СБП
}