﻿using Newtonsoft.Json;

namespace Contracts.YooIntegration;

public sealed class YooWebhookNotification
{
    [JsonProperty("event", Required = Required.Always)]
    public required string Event { get; init; }

    [JsonProperty("object", Required = Required.Always)]
    public required PaymentObject Object { get; init; }
}