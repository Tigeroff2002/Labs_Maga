﻿using Newtonsoft.Json;

namespace Contracts.YooIntegration;

public sealed class YooPaymentResponse
{
    [JsonProperty("id", Required = Required.Always)]
    public required string PaymentId { get; init; }

    [JsonProperty("status", Required = Required.Always)]
    public required string Status { get; init; }

    [JsonProperty("confirmation")]
    public required ConfirmationResponse Confirmation { get; init; }
}
