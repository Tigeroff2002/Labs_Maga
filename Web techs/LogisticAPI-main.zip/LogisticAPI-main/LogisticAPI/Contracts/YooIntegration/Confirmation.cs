﻿using Newtonsoft.Json;

namespace Contracts.Integration;

public sealed class Confirmation
{
    [JsonProperty("type", Required = Required.Always)]
    public string Type => "redirect";

    [JsonProperty("return_url", Required = Required.Always)]
    public required string ReturnUrl { get; init; }
}