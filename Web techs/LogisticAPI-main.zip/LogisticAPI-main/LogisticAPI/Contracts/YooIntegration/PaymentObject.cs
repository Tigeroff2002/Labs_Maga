﻿using Newtonsoft.Json;

namespace Contracts.YooIntegration;

public sealed class PaymentObject
{
    [JsonProperty("id", Required = Required.Always)]
    public required string PaymentId { get; init; }

    [JsonProperty("status", Required = Required.Always)]
    public required string Status { get; init; }

    [JsonProperty("metadata", Required = Required.Always)]
    public required Metadata Metadata { get; init; }
}