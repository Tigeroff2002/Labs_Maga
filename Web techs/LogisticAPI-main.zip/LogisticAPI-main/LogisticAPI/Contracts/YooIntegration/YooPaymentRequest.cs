﻿using Newtonsoft.Json;

namespace Contracts.Integration;

public sealed class YooPaymentRequest
{
    [JsonProperty("amount", Required = Required.Always)]
    public required Amount Amount { get; init; }

    [JsonProperty("payment_method_data", Required = Required.Always)]
    public required PaymentMethodData PaymentMethodData { get; init; }

    [JsonProperty("confirmation", Required = Required.Always)]
    public required Confirmation Confirmation { get; init; }

    [JsonProperty("description", Required = Required.Always)]
    public required string Description { get; init; }

    [JsonProperty("capture", Required = Required.Always)]
    public static bool Capture => false;
}