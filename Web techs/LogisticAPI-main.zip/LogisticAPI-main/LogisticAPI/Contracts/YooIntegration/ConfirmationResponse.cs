﻿using Newtonsoft.Json;

namespace Contracts.YooIntegration;

public sealed class ConfirmationResponse
{
    [JsonProperty("confirmation_url")]
    public string ConfirmationUrl { get; set; }
}