﻿using Newtonsoft.Json;

namespace Contracts.Integration;

public sealed class Amount
{
    [JsonProperty("value", Required = Required.Always)]
    public required string Value { get; init; }

    [JsonProperty("currency", Required = Required.Always)]
    public string Currency => "RUB";
}