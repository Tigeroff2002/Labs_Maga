﻿using Contracts.Integration;
using Newtonsoft.Json;

namespace Contracts.YooIntegration;

public sealed class CapturingRequest
{
    [JsonProperty("amount", Required = Required.Always)]
    public required Amount Amount { get; init; }
}