﻿using Newtonsoft.Json;

namespace Contracts.Responses.GeneratedRoutes;

public sealed class Geometry
{
    [JsonProperty("coordinates")]
    public required List<List<double>> Coordinates { get; init; }
}
