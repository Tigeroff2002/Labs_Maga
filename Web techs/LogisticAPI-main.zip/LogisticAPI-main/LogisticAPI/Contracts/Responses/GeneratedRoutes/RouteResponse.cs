﻿using Newtonsoft.Json;

namespace Contracts.Responses.GeneratedRoutes;

public sealed class RouteResponse
{
    [JsonProperty("geometry", Required = Required.Always)]
    public required Geometry Geometry { get; init; }
}
