﻿using Newtonsoft.Json;

namespace Contracts.Responses.GeneratedRoutes;

public sealed class GeneratedResponse
{
    [JsonProperty("routes", Required = Required.Always)]
    public required List<RouteResponse> Routes { get; init; }
}