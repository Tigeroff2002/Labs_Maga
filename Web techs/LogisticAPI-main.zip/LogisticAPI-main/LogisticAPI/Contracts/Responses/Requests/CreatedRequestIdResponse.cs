﻿using Newtonsoft.Json;

namespace Contracts.Responses.Requests;

public sealed class CreatedRequestIdResponse
{
    [JsonProperty("request_id", Required = Required.Always)]
    public required long RequestId { get; init; }
}