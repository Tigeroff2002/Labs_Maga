﻿using Contracts.Responses.Segments;
using Models;
using Models.Requests;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

namespace Contracts.Responses.Requests;

public sealed class GetUserRequestResultResponse
{
    [JsonProperty("request_id", Required = Required.Always)]
    public required long RequestId { get; init; }

    [JsonConverter(typeof(StringEnumConverter), typeof(SnakeCaseNamingStrategy))]
    [JsonProperty("status", Required = Required.Always)]
    public required RequestStatus RequestStatus { get; init; }

    [JsonConverter(typeof(StringEnumConverter), typeof(SnakeCaseNamingStrategy))]
    [JsonProperty("type", Required = Required.Always)]
    public required RequestType RequestType { get; init; }

    [JsonProperty("creation_date", Required = Required.Always)]
    public required DateTimeOffset CreationDate { get; init; }

    [JsonProperty("coords_range", Required = Required.Always)]
    public required CoordsRangeDTO CoordsRange { get; init; }

    [JsonProperty("initial_segments", Required = Required.Always)]
    public required IReadOnlyCollection<SegmentDTO> InitialSegments { get; init; }

    [JsonProperty("active_segments", Required = Required.Always)]
    public required IReadOnlyCollection<SegmentDTO> ActiveSegments { get; init; } = [];
}