﻿using Newtonsoft.Json;

namespace Contracts.Responses.Requests;

public sealed class GetAllUserRequestsResponse
{
    [JsonProperty("previews", Required = Required.Always)]
    public required IReadOnlyCollection<RequestPreviewDTO> RequestsPreviews { get; init; }
}