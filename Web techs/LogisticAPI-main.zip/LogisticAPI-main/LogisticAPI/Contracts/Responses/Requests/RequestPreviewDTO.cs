﻿using Models;
using Models.Requests;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

namespace Contracts.Responses.Requests;

public sealed class RequestPreviewDTO
{
    [JsonProperty("request_id", Required = Required.Always)]
    public required long RequestId { get; init; }

    [JsonConverter(typeof(StringEnumConverter), typeof(SnakeCaseNamingStrategy))]
    [JsonProperty("status", Required = Required.Always)]
    public required RequestStatus Status { get; init; }

    [JsonConverter(typeof(StringEnumConverter), typeof(SnakeCaseNamingStrategy))]
    [JsonProperty("type", Required = Required.Always)]
    public required RequestType RequestType { get; init; }

    [JsonProperty("creation_date", Required = Required.Always)]
    public required DateTimeOffset CreationDate { get; init; }

    [JsonProperty("last_update", Required = Required.Always)]
    public required DateTimeOffset LastUpdate { get; init; }
}