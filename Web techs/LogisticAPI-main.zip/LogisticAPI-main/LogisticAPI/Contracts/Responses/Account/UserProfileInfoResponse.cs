﻿using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using Models.Account;

namespace Contracts.Responses.Account;

public sealed class UserProfileInfoResponse
{
    [Required]
    [JsonProperty("id", Required = Required.Always)]
    public required long Id { get; init; }

    [Required]
    [JsonProperty("email", Required = Required.Always)]
    public required string Email { get; init; }

    [Required]
    [JsonConverter(typeof(StringEnumConverter), typeof(SnakeCaseNamingStrategy))]
    [JsonProperty("role", Required = Required.Always)]
    public required Role Role { get; init; }

    [JsonProperty("subscription", NullValueHandling = NullValueHandling.Ignore)]
    public Subscription? Subscription { get; init; }

    public static UserProfileInfoResponse FromDomain(UserProfileInfo domain)
    {
        ArgumentNullException.ThrowIfNull(domain);

        return new()
        {
            Id = domain.Id.Value,
            Email = domain.Email.Address,
            Role = domain.Role,
            Subscription = domain.Subscription is null
                ? null
                : new()
                {
                    PaymentId = domain.Subscription.PaymentId.Value,
                    StartDate = domain.Subscription.StartDate,
                    EndDate = domain.Subscription.EndDate
                }
        };
    }
}