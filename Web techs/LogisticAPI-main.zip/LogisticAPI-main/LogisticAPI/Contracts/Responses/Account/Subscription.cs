﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Contracts.Responses.Account;

public sealed class Subscription
{
    [Required]
    [JsonProperty("payment_id", Required = Required.Always)]
    public required long PaymentId { get; init; }

    [Required]
    [JsonProperty("start_date", Required = Required.Always)]
    public required DateTimeOffset StartDate { get; init; }

    [Required]
    [JsonProperty("end_date", Required = Required.Always)]
    public required DateTimeOffset EndDate { get; init; }
}