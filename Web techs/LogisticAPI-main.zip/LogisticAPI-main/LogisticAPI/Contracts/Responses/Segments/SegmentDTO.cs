﻿using Models.Segments;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

namespace Contracts.Responses.Segments;

public sealed class SegmentDTO
{
    [JsonProperty("id", Required = Required.Always)]
    public required long Id { get; init; }

    [JsonConverter(typeof(StringEnumConverter), typeof(SnakeCaseNamingStrategy))]
    [JsonProperty("type", Required = Required.Always)]
    public required SegmentType SegmentType { get; init; }

    [JsonProperty("number", Required = Required.Always)]
    public required int Number { get; init; }

    [JsonProperty("coords_range", Required = Required.Always)]
    public required CoordsRangeDTO CoordsRange { get; init; }

    [JsonProperty("length", Required = Required.Always)]
    public required double Length { get; init; }
}