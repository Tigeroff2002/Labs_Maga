﻿using Models.Payments;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

namespace Contracts.Responses.Payments;

public sealed class VerifyPaymentResponse
{
    [JsonProperty("is_succeeded", Required = Required.Always)]
    public required bool IsSucceeded { get; init; }

    [JsonConverter(typeof(StringEnumConverter), typeof(SnakeCaseNamingStrategy))]
    [JsonProperty("status", Required = Required.Always)]
    public required PaymentStatus Status { get; init; }
}