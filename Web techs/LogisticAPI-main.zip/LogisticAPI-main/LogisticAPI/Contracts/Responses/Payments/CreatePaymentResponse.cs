﻿using Newtonsoft.Json;

namespace Contracts.Responses.Payments;

public sealed class CreatePaymentResponse
{
    [JsonProperty("payment_id", Required = Required.Always)]
    public required string PaymentId { get; init; }

    [JsonProperty("payment_url", Required = Required.Always)]
    public required string PaymentUrl { get; init; }

    [JsonProperty("timestamp", Required = Required.Always)]
    public required DateTimeOffset Timestamp { get; init; }
}