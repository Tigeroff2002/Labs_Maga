﻿using Contracts.Responses.Account;
using Newtonsoft.Json;

namespace Contracts.Responses.Subscriptions;

public sealed class GetUserActiveSubscriptionResponse
{
    [JsonProperty("subscription")]
    public Subscription? Subscription { get; init; }
}