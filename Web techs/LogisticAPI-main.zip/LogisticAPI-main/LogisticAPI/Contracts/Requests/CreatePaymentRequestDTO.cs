﻿using Newtonsoft.Json;

namespace Contracts.Requests;

public sealed class CreatePaymentRequestDTO
{
    [JsonProperty("amount", Required = Required.Always)]
    public required decimal Amount { get; init; }
}