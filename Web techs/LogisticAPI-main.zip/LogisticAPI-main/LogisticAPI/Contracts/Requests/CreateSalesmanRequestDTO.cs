﻿using Newtonsoft.Json;

namespace Contracts.Requests;

public sealed class CreateSalesmanRequestDTO
{
    [JsonProperty("guid", Required = Required.Always)]
    public required string Guid { get; init; }

    [JsonProperty("start_coord", Required = Required.Always)]
    public required CoordDTO StartCoord { get; init; }

    [JsonProperty("to_be_visited_coords", Required = Required.Always)]
    public required IReadOnlyCollection<CoordDTO> ToBeVisitedCoords { get; init; }
}