﻿using Models.Requests;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

namespace Contracts.Requests;

public sealed class ChangeRequestStatusDTO
{
    [JsonProperty("request_id", Required = Required.Always)]
    public required long RequestId { get; init; }

    [JsonConverter(typeof(StringEnumConverter), typeof(SnakeCaseNamingStrategy))]
    [JsonProperty("new_status", Required = Required.Always)]
    public required RequestStatus NewStatus { get; init; }
}