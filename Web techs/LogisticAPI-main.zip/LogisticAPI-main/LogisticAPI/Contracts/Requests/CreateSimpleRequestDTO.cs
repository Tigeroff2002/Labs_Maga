﻿using Newtonsoft.Json;

namespace Contracts.Requests;

public sealed class CreateSimpleRequestDTO
{
    [JsonProperty("guid", Required = Required.Always)]
    public required string Guid { get; init; }

    [JsonProperty("coords_range", Required = Required.Always)]
    public required CoordsRangeDTO CoordsRange { get; init; }
}