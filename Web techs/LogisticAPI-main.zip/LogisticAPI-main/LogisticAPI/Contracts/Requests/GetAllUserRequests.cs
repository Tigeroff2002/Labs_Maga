﻿using Newtonsoft.Json;

namespace Contracts.Requests;

public sealed class GetAllUserRequests
{
    [JsonProperty("user_id", Required = Required.Always)]
    public required long UserId { get; init; }
}