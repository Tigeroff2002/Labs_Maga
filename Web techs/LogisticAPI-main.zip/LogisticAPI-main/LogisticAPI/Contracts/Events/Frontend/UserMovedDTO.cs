﻿using Newtonsoft.Json;

namespace Contracts.Events.Frontend;

public sealed class UserMovedDTO : UserRequestEventDTO
{
    [JsonProperty("request_update", Required = Required.Always)]
    public required UserRequestUpdate RequestUpdate { get; init; }
}