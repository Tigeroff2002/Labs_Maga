﻿namespace Contracts.Events.Frontend;

public enum EventType
{
    UserCreatedRequest,

    UserRecreatedRequest,

    UserAcceptedRequest,

    UserFollowedRequest,

    UserUnfollowedRequest,

    UserClosedRequest,

    UserMoved,

    PaymentStatusUpdated
}