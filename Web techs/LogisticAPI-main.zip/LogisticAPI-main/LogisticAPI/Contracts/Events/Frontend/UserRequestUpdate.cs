﻿using Contracts.Responses.Segments;
using Models;
using Models.Requests;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

namespace Contracts.Events.Frontend;

public sealed class UserRequestUpdate
{
    [JsonProperty("active_segments", Required = Required.Always)]
    public required IReadOnlyCollection<SegmentDTO> ActiveSegments { get; init; }

    [JsonProperty("coords_range", Required = Required.Always)]
    public required CoordsRangeDTO CoordsRange { get; init; }

    [JsonProperty("last_update", Required = Required.Always)]
    public required DateTimeOffset LastUpdate { get; init; }
}