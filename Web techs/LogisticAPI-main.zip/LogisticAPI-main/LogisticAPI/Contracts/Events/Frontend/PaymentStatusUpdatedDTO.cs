﻿using Models.Payments;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

namespace Contracts.Events.Frontend;

public sealed class PaymentStatusUpdatedDTO
{
    [JsonProperty("user_id", Required = Required.Always)]
    public required long UserId { get; init; }

    [JsonProperty("payment_id", Required = Required.Always)]
    public required string PaymentId { get; init; }

    [JsonProperty("last_update", Required = Required.Always)]
    public required DateTimeOffset LastUpdate { get; init; }

    [JsonConverter(typeof(StringEnumConverter), typeof(SnakeCaseNamingStrategy))]
    [JsonProperty("status", Required = Required.Always)]
    public required PaymentStatus Status { get; init; }
}