﻿using Models.Requests;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

namespace Contracts.Events.Frontend;

public class UserRequestEventDTO
{
    [JsonProperty("user_id", Required = Required.Always)]
    public required long UserId { get; init; }

    [JsonProperty("request_id", Required = Required.Always)]
    public required long RequestId { get; init; }

    [JsonProperty("timestamp", Required = Required.Always)]
    public required DateTimeOffset Timestamp { get; init; }

    [JsonConverter(typeof(StringEnumConverter), typeof(SnakeCaseNamingStrategy))]
    [JsonProperty("status", Required = Required.Always)]
    public required RequestStatus RequestStatus { get; init; }

    [JsonConverter(typeof(StringEnumConverter), typeof(SnakeCaseNamingStrategy))]
    [JsonProperty("event_type", Required = Required.Always)]
    public required EventType EventType { get; init; }
}