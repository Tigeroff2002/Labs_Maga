﻿using Contracts.Events.Frontend;
using Newtonsoft.Json;

namespace Contracts.Events.Backend;

public sealed class UserMovedRequest
{
    [JsonProperty("request_id", Required = Required.Always)]
    public required long RequestId { get; init; }

    [JsonProperty("old_coord", Required = Required.Always)]
    public required CoordDTO OldCoord { get; init; }

    [JsonProperty("new_coord", Required = Required.Always)]
    public required CoordDTO NewCoord { get; init; }
}