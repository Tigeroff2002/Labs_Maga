﻿using Newtonsoft.Json;

namespace Contracts;

public sealed class CoordsRangeDTO
{
    [JsonProperty("start_coord", Required = Required.Always)]
    public required CoordDTO StartCoord { get; init; }

    [JsonProperty("end_coord", Required = Required.Always)]
    public required CoordDTO EndCoord { get; init; }
}