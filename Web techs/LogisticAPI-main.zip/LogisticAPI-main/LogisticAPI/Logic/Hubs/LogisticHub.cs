﻿using System.Net.Mail;
using Abstractions.Services;
using Microsoft.AspNetCore.SignalR;
using Models;
using Models.Account;
using System.Security.Claims;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace Logic.Hubs;

[Authorize]
public sealed class LogisticHub : Hub
{
    public LogisticHub(
        IUserIdentityFacade userIdentityFacade,
        IUserService userService,
        ILogger<LogisticHub> logger)
    {
        _userIdentityFacade = userIdentityFacade
            ?? throw new ArgumentNullException(nameof(userIdentityFacade));
        _userService = userService
            ?? throw new ArgumentNullException(nameof(userService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task Notify(string message)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(message);

        await Clients.All.SendAsync("ReceiveNotification", message);
    }

    public override async Task OnConnectedAsync()
    {
        await ManageCurrentUserIdAsync(ActionType.Add, CancellationToken.None);

        await base.OnConnectedAsync();
    }

    public override async Task OnDisconnectedAsync(Exception? exception)
    {
        await ManageCurrentUserIdAsync(ActionType.Remove, CancellationToken.None);

        await base.OnDisconnectedAsync(exception);
    }

    private async Task ManageCurrentUserIdAsync(
        ActionType actionType,
        CancellationToken token)
    {
        var userId = _userIdentityFacade.Id;

        if (userId is not null)
        {
            if (actionType is ActionType.Add)
            {
                await AddUserIdToGroupsAsync(userId, token);
            }
            else
            {
                await RemoveUserIdFromGroupsAsync(userId, token);
            }

            return;
        }

        var context = Context.GetHttpContext();

        if (context is null)
        {
            _logger.LogWarning("There is no active context for hub connection");

            return;
        }

        var email = context.User.FindFirstValue(JwtRegisteredClaimNames.Email);

        if (email is null)
        {
            _logger.LogWarning("There is no email claim found on context for hub connection");

            return;
        }

        var mailAddress = new MailAddress(email);

        var userInfo = await _userService.FindUserProfileInfoByEmailAsync(
            mailAddress,
            CancellationToken.None);

        if (userInfo is null)
        {
            _logger.LogWarning(
                "There is no user with email {Email}" +
                " found on context for hub connection",
                email);

            return;
        }

        if (actionType is ActionType.Add)
        {
            await AddUserIdToGroupsAsync(userInfo.Id, token);
        }
        else
        {
            await RemoveUserIdFromGroupsAsync(userInfo.Id, token);
        }
    }

    private async Task AddUserIdToGroupsAsync(
        Id<User> userId,
        CancellationToken token)
    {
        await Groups.AddToGroupAsync(
            Context.ConnectionId,
            $"User-{userId.Value}",
            token);
    }

    private async Task RemoveUserIdFromGroupsAsync(
        Id<User> userId,
        CancellationToken token)
    {
        await Groups.RemoveFromGroupAsync(
            Context.ConnectionId,
            $"User-{userId.Value}",
            token);
    }

    private enum ActionType
    {
        Add,

        Remove
    }

    private readonly IUserIdentityFacade _userIdentityFacade;
    private readonly IUserService _userService;
    private readonly ILogger _logger;
}