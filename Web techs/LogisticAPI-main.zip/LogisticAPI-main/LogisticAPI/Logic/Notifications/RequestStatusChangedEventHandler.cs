﻿using Contracts.Events.Frontend;
using Logic.Hubs;
using MediatR;
using Microsoft.AspNetCore.SignalR;
using Models.Requests;
using Models.Requests.Events;
using Newtonsoft.Json;

namespace Logic.Notifications;

public sealed class RequestStatusChangedEventHandler :
    INotificationHandler<UserRequestStatusChanged>
{
    public RequestStatusChangedEventHandler(
        IHubContext<LogisticHub> hubContext)
    {
        _hubContext = hubContext
            ?? throw new ArgumentNullException(nameof(hubContext));
    }

    public async Task Handle(
        UserRequestStatusChanged notification,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(notification);

        using var stringWriter = new StringWriter();

        using var writer = new JsonTextWriter(stringWriter);

        var requestStatus = notification.RequestStatusChange.NewStatus;

        var eventType = requestStatus switch
        {
            RequestStatus.Accepted => EventType.UserAcceptedRequest,

            RequestStatus.Followed => EventType.UserFollowedRequest,

            RequestStatus.Unfollowed => EventType.UserUnfollowedRequest,

            RequestStatus.Closed => EventType.UserClosedRequest
        };

        var contract = new UserRequestEventDTO
        {
            UserId = notification.UserId.Value,
            RequestId = notification.RequestId.Value,
            Timestamp = notification.Timestamp,
            RequestStatus = requestStatus,
            EventType = eventType
        };

        _serializer.Serialize(writer, contract);

        await _hubContext.Clients.Group(
            $"User-{notification.UserId.Value}")
                .SendAsync(
                    eventType.ToString(),
                    stringWriter.ToString(),
                    cancellationToken);
    }

    private readonly IHubContext<LogisticHub> _hubContext;

    private static readonly JsonSerializer _serializer = JsonSerializer.CreateDefault();
}