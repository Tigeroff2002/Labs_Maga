﻿using Abstractions.Services;
using MediatR;
using Models.Requests;
using Models.Requests.Events;

namespace Logic.Notifications.Internal;

public sealed class UserArrivedEventHandler :
    INotificationHandler<UserArrived>
{
    public UserArrivedEventHandler(IScopedRequestsService requestsService)
    {
        _requestService = requestsService
            ?? throw new ArgumentNullException(nameof(requestsService));
    }

    public async Task Handle(
        UserArrived notification,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(notification);

        await _requestService.ChangeRequestStatusAsync(
            notification.RequestId,
            RequestStatus.Closed,
            cancellationToken);
    }

    private readonly IScopedRequestsService _requestService;
}