﻿using Contracts.Events.Frontend;
using Logic.Hubs;
using MediatR;
using Microsoft.AspNetCore.SignalR;
using Models.Requests;
using Models.Requests.Events;
using Newtonsoft.Json;

namespace Logic.Notifications;

public sealed class RequestRecreatedEventHandler :
    INotificationHandler<UserRecreatedRequest>
{
    public RequestRecreatedEventHandler(IHubContext<LogisticHub> hubContext)
    {
        _hubContext = hubContext
            ?? throw new ArgumentNullException(nameof(hubContext));
    }

    public async Task Handle(
        UserRecreatedRequest notification,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(notification);

        using var stringWriter = new StringWriter();

        using var writer = new JsonTextWriter(stringWriter);

        var contract = new UserRequestEventDTO
        {
            UserId = notification.UserId.Value,
            RequestId = notification.RequestId.Value,
            Timestamp = notification.Timestamp,
            RequestStatus = RequestStatus.Created,
            EventType = EventType.UserRecreatedRequest
        };

        _serializer.Serialize(writer, contract);

        await _hubContext.Clients.Group(
            $"User-{notification.UserId.Value}")
                .SendAsync(
                    nameof(EventType.UserRecreatedRequest),
                    stringWriter.ToString(),
                    cancellationToken);
    }

    private readonly IHubContext<LogisticHub> _hubContext;

    private static readonly JsonSerializer _serializer = JsonSerializer.CreateDefault();
}