﻿using Contracts.Events.Frontend;
using Contracts.Responses.Segments;
using Logic.Hubs;
using MediatR;
using Microsoft.AspNetCore.SignalR;
using Models.Requests.Events;
using Models.Segments;
using Newtonsoft.Json;

namespace Logic.Notifications;

public sealed class RequestChangedEventHandler :
    INotificationHandler<RequestChanged>
{
    public RequestChangedEventHandler(IHubContext<LogisticHub> hubContext)
    {
        _hubContext = hubContext ?? throw new ArgumentNullException(nameof(hubContext));
    }

    public async Task Handle(
        RequestChanged notification,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(notification);

        using var stringWriter = new StringWriter();

        using var writer = new JsonTextWriter(stringWriter);

        var allRequestSegments = notification.RedrawedRequest.Segments;

        var contract = new UserMovedDTO
        {
            UserId = notification.UserId.Value,
            RequestId = notification.RequestId.Value,
            Timestamp = notification.Timestamp,
            RequestStatus = notification.RedrawedRequest.Status,
            EventType = EventType.UserMoved,
            RequestUpdate = new UserRequestUpdate
            {
                CoordsRange = new()
                {
                    StartCoord = new()
                    {
                        Width = notification.RedrawedRequest.CoordsRange.Start.Width.Value,
                        Heigth = notification.RedrawedRequest.CoordsRange.Start.Height.Value
                    },
                    EndCoord = new()
                    {
                        Width = notification.RedrawedRequest.CoordsRange.End.Width.Value,
                        Heigth = notification.RedrawedRequest.CoordsRange.End.Height.Value
                    }
                },
                ActiveSegments = ConvertToTransport(allRequestSegments, SegmentType.Active),
                LastUpdate = notification.Timestamp
            }
        };

        _serializer.Serialize(writer, contract);

        await _hubContext.Clients.Group(
            $"User-{notification.UserId.Value}")
                .SendAsync(
                    nameof(EventType.UserMoved),
                    stringWriter.ToString(),
                    cancellationToken);
    }

    private IReadOnlyCollection<SegmentDTO> ConvertToTransport(
        IReadOnlyCollection<Segment> segments,
        SegmentType segmentType)
        => segments
            .Where(x => x.SegmentType == SegmentType.Initial)
            .Select(x => new SegmentDTO
            {
                Id = x.Id.Value,
                Number = x.Number.Value,
                SegmentType = segmentType,
                Length = x.Length.Value,
                CoordsRange = new()
                {
                    StartCoord = new()
                    {
                        Width = x.CoordsRange.Start.Width.Value,
                        Heigth = x.CoordsRange.Start.Height.Value
                    },
                    EndCoord = new()
                    {
                        Width = x.CoordsRange.End.Width.Value,
                        Heigth = x.CoordsRange.End.Height.Value
                    }
                }
            })
            .ToList();

    private readonly IHubContext<LogisticHub> _hubContext;

    private readonly JsonSerializer _serializer = JsonSerializer.CreateDefault();
}