﻿using Contracts.Events.Frontend;
using Logic.Hubs;
using MediatR;
using Microsoft.AspNetCore.SignalR;
using Models.Requests.Events;
using Newtonsoft.Json;

namespace Logic.Notifications;

public sealed class PaymentStatusUpdatedHandler : 
    INotificationHandler<PaymentStatusUpdated>
{
    public PaymentStatusUpdatedHandler(IHubContext<LogisticHub> hubContext)
    {
        _hubContext = hubContext ?? throw new ArgumentNullException(nameof(hubContext));
    }

    public async Task Handle(
        PaymentStatusUpdated notification,
        CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(notification);

        using var stringWriter = new StringWriter();

        using var writer = new JsonTextWriter(stringWriter);

        var contract = new PaymentStatusUpdatedDTO
        {
            UserId = notification.UserId.Value,
            PaymentId = notification.PaymentGUID.Value,
            LastUpdate = notification.Timestamp,
            Status = notification.Status
        };

        _serializer.Serialize(writer, contract);

        await _hubContext.Clients.Group(
            $"User-{notification.UserId.Value}")
                .SendAsync(
                    nameof(EventType.PaymentStatusUpdated),
                    stringWriter.ToString(),
                    cancellationToken);
    }

    private readonly IHubContext<LogisticHub> _hubContext;

    private static readonly JsonSerializer _serializer = JsonSerializer.CreateDefault();
}