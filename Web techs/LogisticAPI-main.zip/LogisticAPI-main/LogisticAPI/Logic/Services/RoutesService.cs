﻿using System.Diagnostics;
using System.Globalization;
using Abstractions.Services;
using Contracts.Responses.GeneratedRoutes;
using Models;
using Models.Segments;
using Newtonsoft.Json;

namespace Logic.Services;

public sealed class RoutesService : IRoutesService
{
    public RoutesService()
    {
        _httpClient = new HttpClient();
    }

    public async Task<CreatedDistanse> GenerateSegmentsAsync(
        CoordsRange coordsRange,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(coordsRange);

        var requestUrl =
            $"{DirectionsUrl}" +
            $"{coordsRange.Start.Height.Value.ToString("F5", CultureInfo.InvariantCulture)}," +
            $"{coordsRange.Start.Width.Value.ToString("F5", CultureInfo.InvariantCulture)};" +
            $"{coordsRange.End.Height.Value.ToString("F5", CultureInfo.InvariantCulture)}," +
            $"{coordsRange.End.Width.Value.ToString("F5", CultureInfo.InvariantCulture)}" +
            $"?overview=full&steps=true&geometries=geojson";

        var response = await _httpClient.GetStringAsync(requestUrl);

        var routesResponse = JsonConvert.DeserializeObject<GeneratedResponse>(response);

        Debug.Assert(routesResponse != null);

        var coordinates = routesResponse.Routes
            .SelectMany(r => r.Geometry.Coordinates)
            .Select(c => (Longitude: c[0], Latitude: c[1]))
            .ToList();

        var number = 0;
        var segments = new List<CreatingSegment>();

        for (int i = 0; i < coordinates.Count - 1; i++)
        {
            var startStep = coordinates[i];
            var endStep = coordinates[i + 1];

            var startCoord = new CoordPair(
                new(startStep.Latitude),
                new(startStep.Longitude));

            var endCoord = new CoordPair(
                new(endStep.Latitude),
                new(endStep.Longitude));

            var coordRange = new CoordsRange(startCoord, endCoord);

            var segment = new CreatingSegment(
                coordRange,
                new(coordRange.GetDistanceMetres()),
                new(++number));

            segments.Add(segment);
        }

        return new(segments);
    }

    private const string DirectionsUrl = "https://router.project-osrm.org/route/v1/driving/";

    private readonly HttpClient _httpClient;
}