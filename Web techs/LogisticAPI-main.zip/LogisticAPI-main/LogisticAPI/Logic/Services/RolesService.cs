﻿using Abstractions.Services;
using Abstractions.Storage;
using Models.Account;
using Models;

namespace Logic.Services;

public sealed class RolesService : IRolesService
{
    public RolesService(ILogisticUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork
            ?? throw new ArgumentNullException(nameof(unitOfWork));
    }

    public async Task<Role> GetUserRoleAsync(
        Id<User> userId,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(userId);

        return await _unitOfWork.Users.GetUserRoleAsync(userId, token);
    }

    private readonly ILogisticUnitOfWork _unitOfWork;
}