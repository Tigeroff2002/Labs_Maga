﻿using System.ComponentModel;
using Abstractions.Services;
using Microsoft.Extensions.DependencyInjection;
using Models;
using Models.Requests;

namespace Logic.Services;

public sealed class ScopedRequestsService : IScopedRequestsService
{
    public ScopedRequestsService(IServiceScopeFactory scopeFactory)
    {
        _scopeFactory = scopeFactory
            ?? throw new ArgumentNullException(nameof(scopeFactory));
    }

    public async Task ProcessUserMovementAsync(
        UserMoved userMoved,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(userMoved);

        var scopedService = 
            _scopeFactory.CreateScope().ServiceProvider.GetRequiredService<IRequestsService>();

        await scopedService.ProcessUserMovementAsync(userMoved, token);
    }

    public async Task ChangeRequestStatusAsync(
        Id<Request> requestId, 
        RequestStatus newStatus,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(requestId);

        if (!Enum.IsDefined(typeof(RequestStatus), newStatus))
        {
            throw new InvalidEnumArgumentException(
                nameof(newStatus),
                (int)newStatus,
                typeof(RequestStatus));
        }

        var scopedService =
            _scopeFactory.CreateScope().ServiceProvider.GetRequiredService<IRequestsService>();


        await scopedService.ChangeRequestStatusAsync(requestId, newStatus, token);
    }

    private readonly IServiceScopeFactory _scopeFactory;
}