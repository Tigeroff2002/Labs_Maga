﻿using System.Globalization;
using System.Text;
using Abstractions.Services;
using Abstractions.Storage;
using Contracts.Integration;
using Contracts.YooIntegration;
using Logic.Services.Configuration;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Models;
using Models.Payments;
using Models.Requests.Events;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace Logic.Services;

public sealed class PaymentService : IPaymentService
{
    public PaymentService(
        IOptions<PaymentConfiguration> options,
        ILogger<PaymentService> logger,
        ILogisticUnitOfWork unitOfWork,
        IMediator mediator)
    {
        _configuration = options?.Value ?? throw new ArgumentNullException(nameof(options));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
    }

    public async Task<PaymentCreated> CreatePaymentAsync(
        PaymentRequest requestPayment,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(requestPayment);

        _logger.LogDebug(
            "Created new payment with id for user {UserId}",
            requestPayment.UserId.Value);

        using var client = new RestClient(_apiUrl);

        var request = new RestRequest("payments", Method.Post);

        request.AddHeader(
            "Authorization",
            $"Basic {Convert.ToBase64String(
                Encoding.UTF8.GetBytes($"{_configuration.ShopId}:{_configuration.SecretKey}"))}");
        request.AddHeader("Idempotence-Key", Guid.NewGuid().ToString());

        var body = new YooPaymentRequest
        {
            Amount = new Contracts.Integration.Amount
            {
                Value = requestPayment.Amount.Value.ToString("0.00", CultureInfo.InvariantCulture),
            },
            PaymentMethodData = new PaymentMethodData(),
            Confirmation = new()
            {
                ReturnUrl = _configuration.ReturnUrl
            },
            Description = $"Оплата заказа '{requestPayment.PaymentGuid.Value}'"
        };

        var stringBody = JsonConvert.SerializeObject(body);

        request.AddJsonBody(stringBody);

        var response = await client.ExecuteAsync<YooPaymentResponse>(request);

        if (response.StatusCode != System.Net.HttpStatusCode.OK)
        {
            throw new InvalidOperationException(
                "Failed to receive url for continueing payment'.");
        }

        var badRequestResponse = JObject.Parse(response.Content!);

        var paymentGuId = badRequestResponse["id"]!.ToString();
        var confirmationUrl = badRequestResponse["confirmation"]!["confirmation_url"]!.ToString();

        var yooMoneyPaymentId = new PaymentGUID(paymentGuId);

        var updatedRequest = new PaymentRequest(
            requestPayment.UserId,
            requestPayment.Amount,
            yooMoneyPaymentId);

        await _unitOfWork.Payments.AddPaymentTransactionAsync(updatedRequest, token);

        await _unitOfWork.SaveAsync(token);

        return new(
            yooMoneyPaymentId, 
            confirmationUrl);
    }

    public async Task HandlePaymentUpdateAsync(
        PaymentGUID paymentGuid,
        string status,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(paymentGuid);

        ArgumentException.ThrowIfNullOrWhiteSpace(status);

        var (payment, currentStatus) = await SynchronizeStatusAndCommitPaymentIfNevessaryAsync(
            paymentGuid, 
            status, 
            token);

        await _mediator.Publish(
            new PaymentStatusUpdated(
                payment.UserId,
                paymentGuid,
                currentStatus,
                payment.LastUpdate));
    }

    public async Task<PaymentStatus> VerifyStatusPaymentAsync(
        PaymentGUID paymentGUID,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(paymentGUID);

        using var client = new RestClient(_apiUrl);

        var request = new RestRequest($"payments/{paymentGUID.Value}", Method.Get);

        request.AddHeader(
            "Authorization",
            $"Basic {Convert.ToBase64String(
                Encoding.UTF8.GetBytes($"{_configuration.ShopId}:{_configuration.SecretKey}"))}");
        request.AddHeader("Idempotence-Key", Guid.NewGuid().ToString());

        var response = await client.ExecuteAsync<PaymentObject>(request);

        if (response.StatusCode != System.Net.HttpStatusCode.OK)
        {
            throw new InvalidOperationException(
                $"Failed to receive info about payment status.");
        }

        var badRequestResponse = JObject.Parse(response.Content!);

        var stringStatusValue = badRequestResponse["status"]!.ToString();

        var amountValue = (decimal)badRequestResponse["amount"]!["value"]!;

        var (_, status) = await SynchronizeStatusAndCommitPaymentIfNevessaryAsync(
            paymentGUID,
            stringStatusValue,
            token,
            amountValue);

        return status;
    }

    private async Task<(Payment, PaymentStatus)> SynchronizeStatusAndCommitPaymentIfNevessaryAsync(
        PaymentGUID paymentGuid,
        string? status,
        CancellationToken token,
        decimal? amountValue = null)
    {
        var currentStatus = status switch
        {
            "pending" => PaymentStatus.Pending,

            "waiting_for_capture" => PaymentStatus.WaitingForCapture,

            "succeeded" => PaymentStatus.Succeeded,

            "canceled" => PaymentStatus.Canceled,

            "authorized" => PaymentStatus.Authorized,

            "parially_refunded" => PaymentStatus.PariallyRefunded,

            "refunded" => PaymentStatus.Refunded,

            "failed" => PaymentStatus.Failed,

            _ => throw new InvalidOperationException(
                $"Invalid payment status '{status}' was received from YooMoney")
        };

        await _unitOfWork.Payments.UpdatePaymentStatusAsync(
            paymentGuid,
            currentStatus,
            token);

        _logger.LogDebug(
            "Payment with guid {PaymentGuid} received new status '{NewStatus}'",
            paymentGuid.Value,
            status);

        var payment = await _unitOfWork.Payments.GetPaymentByGuidAsync(
            paymentGuid,
            token);

        if (currentStatus == PaymentStatus.WaitingForCapture)
        {
            using var client = new RestClient(_apiUrl);

            var request = new RestRequest($"payments/{paymentGuid.Value}/capture", Method.Post);

            request.AddHeader(
                "Authorization",
                $"Basic {Convert.ToBase64String(
                    Encoding.UTF8.GetBytes($"{_configuration.ShopId}:{_configuration.SecretKey}"))}");
            request.AddHeader("Idempotence-Key", Guid.NewGuid().ToString());

            var body = new CapturingRequest
            {
                Amount = new()
                {
                    Value = amountValue!.Value.ToString("0.00", CultureInfo.InvariantCulture)
                }
            };

            var stringBody = JsonConvert.SerializeObject(body);

            request.AddJsonBody(stringBody);

            await client.ExecuteAsync<CapturingRequest>(request);

            _logger.LogDebug(
                "Payment '{Guid}' was captured and so should be succeeded", 
                paymentGuid.Value);

            var totalDaysSubscription =
                (int)((payment.Amount.Value / SUBSCRIPTION_COST_PER_MONTH) * 30);

            await _unitOfWork.Subscriptions.AddSubscriptionAsync(
                new(
                    payment.UserId,
                    payment.PaymentId,
                    TimeSpan.FromDays(totalDaysSubscription)),
                token);

            _logger.LogDebug(
                "Added a subcription for {TotalDays} days for user with id {UserId}",
                totalDaysSubscription,
                payment.UserId.Value);
        }

        await _unitOfWork.SaveAsync(token);

        return (payment, currentStatus);
    }

    private readonly PaymentConfiguration _configuration;
    private readonly ILogger _logger;
    private readonly ILogisticUnitOfWork _unitOfWork;
    private readonly IMediator _mediator;

    private const int SUBSCRIPTION_COST_PER_MONTH = 50;

    private readonly string _apiUrl = "https://api.yookassa.ru/v3/";
}