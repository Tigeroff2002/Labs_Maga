﻿using System.ComponentModel.DataAnnotations;

namespace Logic.Services.Configuration;

public sealed class PaymentConfiguration
{
    [Required]
    public required string ReturnUrl { get; init; }

    [Required]
    public required string ShopId { get; init; }

    [Required]
    public required string SecretKey { get; init; }
}