﻿using Microsoft.Extensions.Options;

namespace Logic.Services.Configuration;

[OptionsValidator]
public sealed partial class PaymentConfigurationValidator :
    IValidateOptions<PaymentConfiguration>
{
}
