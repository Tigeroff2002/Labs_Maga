﻿using System.Net.Mail;
using Abstractions.Services;
using Abstractions.Storage;
using Microsoft.Extensions.Logging;
using Models.Account;
using Models;

namespace Logic.Services;

public sealed class UsersService : IUserService
{
    public UsersService(
        ILogisticUnitOfWork unitOfWork,
        ILogger<UsersService> logger)
    {
        _unitOfWork = unitOfWork
            ?? throw new ArgumentNullException(nameof(unitOfWork));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<UserProfileInfo?> FindUserProfileInfoByEmailAsync(
        MailAddress mailAddress,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(mailAddress);

        token.ThrowIfCancellationRequested();

        return await _unitOfWork.Users.FindUserProfileInfoByEmailAsync(mailAddress, token);
    }

    public async Task<UserProfileInfo> RegisterNewUserAsync(
        RegisteringUser registeringUser,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(registeringUser);

        token.ThrowIfCancellationRequested();

        var existingUser = await _unitOfWork.Users
            .FindUserProfileInfoByEmailAsync(registeringUser.Email, token);

        if (existingUser is not null)
        {
            throw new InvalidOperationException(
                $"User with email: {existingUser!.Email.User.Take(3)}" +
                $"***@{existingUser.Email.Host.Take(3)}***" +
                " already exists.");
        }

        await _unitOfWork.Users.AddUserAsync(registeringUser, token);

        await _unitOfWork.SaveAsync(token);

        existingUser = await _unitOfWork.Users
            .FindUserProfileInfoByEmailAsync(registeringUser.Email, token);

        _logger.LogInformation(
            "New user registered with email: {EmailPattern}",
            $"{existingUser!.Email.User.Take(3)}***@{existingUser.Email.Host.Take(3)}***");

        return existingUser;
    }

    public async Task<UserProfileInfo> GetUserProfileInfoAsync(
        Id<User> userId,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(userId);

        var rawInfo =
            await _unitOfWork.Users.GetUserProfileInfoByIdAsync(userId, token);

        var activeSubscription = 
            await _unitOfWork.Subscriptions.FindActiveUserSubscriptionAsync(
                userId,
                token);

        return new(userId, rawInfo.Email, rawInfo.Role, activeSubscription);
    }

    private readonly ILogisticUnitOfWork _unitOfWork;
    private readonly ILogger<UsersService> _logger;
}