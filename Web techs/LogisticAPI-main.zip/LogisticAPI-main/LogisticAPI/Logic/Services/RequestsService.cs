﻿using System.ComponentModel;
using Abstractions.Services;
using Abstractions.Storage;
using MediatR;
using Microsoft.Extensions.Logging;
using Models;
using Models.Requests;
using Models.Requests.Events;
using Models.Segments;

namespace Logic.Services;

public sealed class RequestsService :
    IRequestsService
{
    public RequestsService(
        IMediator mediator,
        ILogisticUnitOfWork unitOfWork,
        ILogger<RequestsService> logger,
        IUserIdentityFacade userIdentityFacade,
        IRoutesService routesService)
    {
        _mediator = mediator
            ?? throw new ArgumentNullException(nameof(mediator));
        _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        _logger = logger ?? throw new ArgumentNullException(nameof(_logger));
        _userIdentityFacade = userIdentityFacade
            ?? throw new ArgumentNullException(nameof(userIdentityFacade));
        _routesService = routesService ?? throw new ArgumentNullException(nameof(routesService));
    }

    public async Task<Id<Request>> CreateSimpleRequestAsync(
        Name<Request> requestGuid,
        CoordsRange coordsRange,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(requestGuid);
        ArgumentNullException.ThrowIfNull(coordsRange);

        var initialDistanse =
            await _routesService.GenerateSegmentsAsync(coordsRange, token);

        var userId = _userIdentityFacade.Id!;

        await _unitOfWork.Requests.CreateRequestAsync(
            new(
                userId, 
                requestGuid, 
                coordsRange,
                RequestType.Simple, 
                initialDistanse.Segments),
            token);

        await _unitOfWork.SaveAsync(token);

        var requestId =
            await _unitOfWork.Requests.GetRequestIdByGuidAsync(requestGuid, token);

        await _mediator.Publish(
            new UserCreatedRequest(
                userId,
                requestId,
                DateTimeOffset.UtcNow),
            token);

        return requestId;
    }

    public async Task<Id<Request>> CreateTravellingSalesmanRequestAsync(
        Name<Request> requestGuid,
        TravellingSalesmanCoords coordsModel,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(requestGuid);
        ArgumentNullException.ThrowIfNull(coordsModel);

        var pointsCount = coordsModel.ToBeVisited.Count + 1;

        var distances = new double[pointsCount, pointsCount];

        var creatingSegments = new CreatedDistanse[pointsCount, pointsCount];

        var points = new List<CoordPair>
        {
            coordsModel.Start
        };

        foreach (var point in coordsModel.ToBeVisited)
        {
            points.Add(point);
        }

        for (var i = 0; i < pointsCount; i++)
        {
            for (var j = i + 1; j < pointsCount - 1; j++)
            {
                if (distances[j, i] != 0)
                {
                    distances[i, j] = distances[j, i];

                    continue;
                }

                var currentDistanse =
                    await _routesService.GenerateSegmentsAsync(new(points[i], points[j]), token);

                distances[i, j] = currentDistanse.TotalLength;

                creatingSegments[i, j] = currentDistanse;
            }
        }

        var finder = new OptimalRouteFinder(distances, startNode: 0);

        var optimalRouteSequence = finder.FindOptimalTour();

        var concatedTravellingSalesmanSegments = new List<CreatingSegment>();

        for (var k = 0; k < optimalRouteSequence.Count - 1; k++)
        {
            var currentDistanse = creatingSegments[k, k + 1];

            concatedTravellingSalesmanSegments.Concat(currentDistanse.Segments);
        }

        var userId = _userIdentityFacade.Id!;

        await _unitOfWork.Requests.CreateRequestAsync(
            new(
                userId,
                requestGuid,
                new(coordsModel.Start, points[optimalRouteSequence[pointsCount - 1]]),
                RequestType.TravellingSalesman,
                concatedTravellingSalesmanSegments),
            token);

        await _unitOfWork.SaveAsync(token);

        var requestId =
            await _unitOfWork.Requests.GetRequestIdByGuidAsync(requestGuid, token);

        await _mediator.Publish(
            new UserCreatedRequest(
                userId,
                requestId,
                DateTimeOffset.UtcNow),
            token);

        return requestId;
    }

    public async Task RecreateRequestAsync(
        Id<Request> requestId,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(requestId);

        var userId = _userIdentityFacade.Id!;

        var storageRequest = await GetRequestByIdAsync(requestId, token);

        if (storageRequest.RequestType == RequestType.TravellingSalesman)
        {
            var exceptionText = "Cant recreate travelling salesman request, skipping";

            _logger.LogWarning(exceptionText);

            throw new InvalidOperationException(exceptionText);
        }

        var initialDistanse =
            await _routesService.GenerateSegmentsAsync(
                storageRequest.CoordsRange,
                token);

        await _unitOfWork.Requests.RecreateRequestAsync(
            new(userId, requestId, initialDistanse.Segments),
            token);

        await _unitOfWork.SaveAsync(token);

        await _mediator.Publish(
            new UserRecreatedRequest(
                userId,
                requestId,
                DateTimeOffset.UtcNow),
            token);
    }

    public async Task ChangeRequestStatusAsync(
        Id<Request> requestId,
        RequestStatus newStatus,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(requestId);

        if (!Enum.IsDefined(typeof(RequestStatus), newStatus))
        {
            throw new InvalidEnumArgumentException(
                nameof(newStatus),
                (int)newStatus,
                typeof(RequestStatus));
        }

        var storageRequest = await GetRequestByIdAsync(requestId, token);

        await _unitOfWork.Requests.ChangeRequestStatusAsync(
            new(requestId, storageRequest.Status, newStatus),
            token);

        await _unitOfWork.SaveAsync(token);

        _logger.LogInformation(
            "For request {RequestId} status {OldStatus}" +
            " has been changed to new status {NewStatus}",
            requestId.Value,
            storageRequest.Status,
            newStatus);

        await _mediator.Publish(
            new UserRequestStatusChanged(
                _userIdentityFacade.Id!,
                new(requestId, storageRequest.Status, newStatus),
                DateTimeOffset.UtcNow),
            token);
    }

    public async Task<Request> GetRequestByIdAsync(
        Id<Request> requestId,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(requestId);

        return await _unitOfWork.Requests.GetRequestByIdAsync(requestId, token);
    }

    public Task<IReadOnlyCollection<RequestPreview>> GetAllUserRequestsPreviewsAsync(
        CancellationToken token)
    {
        var userId = _userIdentityFacade.Id!;

        return _unitOfWork.Requests.GetAllUserRequestsPreviewsAsync(userId, token);
    }

    public async Task ProcessUserMovementAsync(
        UserMoved userMoved,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(userMoved);

        if (!await _unitOfWork.Requests
            .IsRequestRelatedToMe(userMoved.RequestId, userMoved.UserId, token))
        {
            throw new InvalidOperationException(
                $"User {userMoved.UserId.Value}" +
                $" not creator of request {userMoved.RequestId.Value}.");
        }

        var request = 
            await _unitOfWork.Requests.GetRequestByIdAsync(userMoved.RequestId, token);

        if (request.RequestType == RequestType.TravellingSalesman)
        {
            var exceptionText = "Cant process movement on travelling salesman request, skipping";

            _logger.LogWarning(exceptionText);

            throw new InvalidOperationException(exceptionText);
        }

        var now = DateTimeOffset.UtcNow;

        if (request.CoordsRange.End == userMoved.NewCoord)
        {
            await _mediator.Publish(
                new UserArrived(
                    userMoved.UserId,
                    userMoved.RequestId,
                    now),
                token);
        }

        await UpdateActiveSegmentsAsync(request, userMoved.NewCoord, token);

        await _mediator.Publish(
            new RequestChanged(
                userMoved.UserId,
                now,
                request),
            token);
    }

    private async Task UpdateActiveSegmentsAsync(
        Request request,
        CoordPair userCoord,
        CancellationToken token)
    {
        var activeCoordsRange = new CoordsRange(userCoord, request.CoordsRange.End);

        var activeDistanse =
            await _routesService.GenerateSegmentsAsync(activeCoordsRange, token);

        await _unitOfWork.Requests.UpdateRequestActiveSegments(
            request.Id,
            activeDistanse.Segments,
            token);

        await _unitOfWork.SaveAsync(token);
    }

    private readonly ILogisticUnitOfWork _unitOfWork;
    private readonly ILogger _logger;
    private readonly IUserIdentityFacade _userIdentityFacade;
    private readonly IRoutesService _routesService;
    private readonly IMediator _mediator;
}