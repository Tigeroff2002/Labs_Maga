﻿using Abstractions.Services;
using Abstractions.Storage;
using Models;
using Models.Account;
using Models.Subscriptions;

namespace Logic.Services;

public sealed class SubscriptionService : ISubscriptionService
{
    public SubscriptionService(ILogisticUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork 
            ?? throw new ArgumentNullException(nameof(unitOfWork));
    }

    public Task<Subscription?> FindActiveUserSubcriptionAsync(
        Id<User> userId,
        CancellationToken token)
    {
        ArgumentNullException.ThrowIfNull(userId);

        token.ThrowIfCancellationRequested();

        return _unitOfWork.Subscriptions.FindActiveUserSubscriptionAsync(userId, token);
    }

    private readonly ILogisticUnitOfWork _unitOfWork;
}