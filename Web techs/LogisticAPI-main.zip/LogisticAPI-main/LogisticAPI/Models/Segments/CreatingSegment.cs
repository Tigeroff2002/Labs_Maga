﻿using Models.Requests;

namespace Models.Segments;

public sealed class CreatingSegment
{
    public CoordsRange CoordsRange { get; }

    public Length<Segment> Length { get; }

    public Number Number { get; }

    public CreatingSegment(
        CoordsRange coordsRange, 
        Length<Segment> length,
        Number number)
    {
        CoordsRange = coordsRange 
            ?? throw new ArgumentNullException(nameof(coordsRange));
        Length = length ?? throw new ArgumentNullException(nameof(length));
        Number = number ?? throw new ArgumentNullException(nameof(number));
    }
}