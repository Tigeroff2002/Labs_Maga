﻿namespace Models.Segments;

public sealed class Length<tEntity>
{
    public double Value { get; }

    public Length(double value)
    {
        ArgumentOutOfRangeException.ThrowIfLessThanOrEqual(value, MIN);

        Value = value;
    }

    private const double MIN = 0;
}