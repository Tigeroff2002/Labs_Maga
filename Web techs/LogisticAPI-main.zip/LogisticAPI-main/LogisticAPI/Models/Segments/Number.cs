﻿namespace Models.Segments;

public sealed record class Number
{
    public int Value { get; }

    public Number(int value)
    {
        ArgumentOutOfRangeException.ThrowIfLessThan(value, MIN);
        ArgumentOutOfRangeException.ThrowIfGreaterThan(value, MAX);

        Value = value;
    }

    private const int MIN = 1;
    private const int MAX = 1000;
}