﻿using System.ComponentModel;
using Models.Requests;

namespace Models.Segments;

public sealed class Segment
{
    public Id<Segment> Id { get; }

    public Id<Request> RequestId { get; }

    public SegmentType SegmentType { get; }

    public CoordsRange CoordsRange { get; }

    public Length<Segment> Length { get; }

    public Number Number { get; }

    public Segment(
        Id<Segment> id,
        Id<Request> requestId,
        SegmentType segmentType,
        CoordsRange coordsRange,
        Length<Segment> length,
        Number number)
    {
        Id = id ?? throw new ArgumentNullException(nameof(id));
        RequestId = requestId ?? throw new ArgumentNullException(nameof(requestId));
        CoordsRange = coordsRange
            ?? throw new ArgumentNullException(nameof(coordsRange));
        Length = length ?? throw new ArgumentNullException(nameof(length));
        Number = number ?? throw new ArgumentNullException(nameof(number));

        if (!Enum.IsDefined(typeof(SegmentType), segmentType))
        {
            throw new InvalidEnumArgumentException(
                nameof(segmentType),
                (int)segmentType,
                typeof(SegmentType));
        }

        SegmentType = segmentType;
    }
}