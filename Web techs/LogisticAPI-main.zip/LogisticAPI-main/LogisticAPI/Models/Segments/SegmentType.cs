﻿namespace Models.Segments;

public enum SegmentType
{
    Initial,

    Active
}