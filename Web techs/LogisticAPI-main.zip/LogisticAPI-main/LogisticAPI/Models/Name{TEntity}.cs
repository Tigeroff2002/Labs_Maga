﻿namespace Models;

public sealed record class Name<TEntity>
{
    public string Value { get; }

    public Name(string value)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(value);

        Value = value;
    }
}