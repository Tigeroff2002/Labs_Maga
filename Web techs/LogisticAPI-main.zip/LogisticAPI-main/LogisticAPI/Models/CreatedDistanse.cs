﻿using Models.Segments;

namespace Models;

public sealed class CreatedDistanse
{
    public IReadOnlyCollection<CreatingSegment> Segments { get; }

    public double TotalLength { get; }

    public CreatedDistanse(IReadOnlyCollection<CreatingSegment> segments)
    {
        ArgumentNullException.ThrowIfNull(segments);

        if (segments.Count == 0)
        {
            throw new ArgumentException("Segments count should be greater than 0.");
        }

        Segments = segments;

        TotalLength = segments.Select(s => s.Length.Value).Sum();
    }
}