﻿namespace Models.Payments;

public sealed record class PaymentGUID
{
    public string Value { get; }

    public PaymentGUID(string value)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(value);
        Value = value;
    }
}