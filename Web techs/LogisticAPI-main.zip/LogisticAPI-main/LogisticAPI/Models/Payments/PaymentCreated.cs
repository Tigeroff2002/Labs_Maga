﻿namespace Models.Payments;

public sealed class PaymentCreated
{
    public PaymentGUID PaymentGuid { get; }

    public string PaymentUrl { get; }

    public PaymentCreated(
        PaymentGUID paymentGuid,
        string paymentUrl)
    {
        ArgumentNullException.ThrowIfNull(paymentGuid);
        PaymentGuid = paymentGuid;

        ArgumentException.ThrowIfNullOrWhiteSpace(paymentUrl);
        PaymentUrl = paymentUrl;
    }
}