﻿namespace Models.Payments;

public sealed record Amount
{
    public decimal Value { get; }

    public Amount(decimal value)
    {
        ArgumentOutOfRangeException.ThrowIfLessThanOrEqual(value, MIN);

        Value = value;
    }

    private const decimal MIN = 0;
}
