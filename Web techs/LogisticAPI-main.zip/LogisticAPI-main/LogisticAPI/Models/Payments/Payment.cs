﻿using System.ComponentModel;
using Models.Account;

namespace Models.Payments;

public sealed class Payment
{
    public Id<User> UserId { get; }

    public Id<Payment> PaymentId { get; }

    public PaymentGUID PaymentGuid { get; }

    public Amount Amount { get; }

    public DateTimeOffset CreationDate { get; }

    public DateTimeOffset LastUpdate { get; }

    public PaymentStatus Status { get; }

    public Payment(
        Id<User> userId,
        Id<Payment> paymentId,
        PaymentGUID paymentGuid,
        Amount amount, 
        DateTimeOffset creationDate, 
        DateTimeOffset lastUpdate,
        PaymentStatus status)
    {
        UserId = userId ?? throw new ArgumentNullException(nameof(userId));
        Amount = amount ?? throw new ArgumentNullException(nameof(amount));
        PaymentId = paymentId ?? throw new ArgumentNullException(nameof(paymentId));
        PaymentGuid = paymentGuid ?? throw new ArgumentNullException(nameof(paymentGuid));

        ArgumentOutOfRangeException.ThrowIfGreaterThan(creationDate, DateTimeOffset.UtcNow);
        ArgumentOutOfRangeException.ThrowIfLessThan(lastUpdate, creationDate);

        CreationDate = creationDate;
        LastUpdate = lastUpdate;

        if (!Enum.IsDefined(typeof(PaymentStatus), status))
        {
            throw new InvalidEnumArgumentException(nameof(status));
        }

        Status = status;
    }
}