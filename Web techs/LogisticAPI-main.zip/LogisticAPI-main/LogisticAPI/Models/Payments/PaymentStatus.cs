﻿namespace Models.Payments;

public enum PaymentStatus
{
    Pending,

    WaitingForCapture,

    Succeeded,

    Canceled,

    Authorized,

    PariallyRefunded,

    Refunded,

    Failed
}