﻿using Models.Account;

namespace Models.Payments;

public sealed class PaymentRequest
{
    public Id<User> UserId { get; }

    public Amount Amount { get; }

    public PaymentGUID PaymentGuid { get; }

    public PaymentRequest(
        Id<User> userId,
        Amount amount,
        PaymentGUID paymentGuid)
    {
        UserId = userId ?? throw new ArgumentNullException(nameof(userId));
        Amount = amount ?? throw new ArgumentNullException(nameof(amount));
        PaymentGuid = paymentGuid;
    }
}