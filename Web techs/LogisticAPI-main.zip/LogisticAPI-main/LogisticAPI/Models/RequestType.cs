﻿namespace Models;

public enum RequestType
{
    Simple,

    TravellingSalesman
}
