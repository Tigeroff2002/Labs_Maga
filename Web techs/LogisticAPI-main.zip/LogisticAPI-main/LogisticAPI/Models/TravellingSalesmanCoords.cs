﻿namespace Models;

public sealed class TravellingSalesmanCoords
{
    public CoordPair Start { get; }

    public IReadOnlySet<CoordPair> ToBeVisited { get; }

    public TravellingSalesmanCoords(
        CoordPair start,
        IReadOnlySet<CoordPair> toBeVisited)
    {
        Start = start ?? throw new ArgumentNullException(nameof(start));
        
        ArgumentNullException.ThrowIfNull(toBeVisited);

        if (toBeVisited.Count == 0)
        {
            throw new ArgumentException("To be visited points count should be > 0");
        }

        foreach (var point in toBeVisited)
        {
            if (Start == point)
            {
                throw new ArgumentException("All points should be different.");
            }
        }

        ToBeVisited = toBeVisited;
    }
}