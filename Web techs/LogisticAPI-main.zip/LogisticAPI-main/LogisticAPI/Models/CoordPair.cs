﻿namespace Models;

public sealed record CoordPair
{
    public Coord Width { get; }

    public Coord Height { get; }

    public CoordPair(Coord width, Coord height)
    {
        Width = width ?? throw new ArgumentNullException(nameof(width));
        Height = height ?? throw new ArgumentNullException(nameof(height));
    }

    public bool Equals(CoordPair? other)
    {
        if (other is null) return false;

        return GetDistanceInMeters(this, other) <= TOLERANCE_METRES;
    }

    public override int GetHashCode()
    {
        return HashCode.Combine(
            Math.Round(Width.Value, 4),
            Math.Round(Height.Value, 4)
        );
    }

    public static double GetDistanceInMeters(CoordPair a, CoordPair b)
    {
        const double EarthRadius = 6371000; // Радиус Земли в метрах

        double lat1 = DegreesToRadians(a.Width.Value);
        double lon1 = DegreesToRadians(a.Height.Value);
        double lat2 = DegreesToRadians(b.Width.Value);
        double lon2 = DegreesToRadians(b.Height.Value);

        double dLat = lat2 - lat1;
        double dLon = lon2 - lon1;

        double h = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                   Math.Cos(lat1) * Math.Cos(lat2) *
                   Math.Sin(dLon / 2) * Math.Sin(dLon / 2);

        double c = 2 * Math.Atan2(Math.Sqrt(h), Math.Sqrt(1 - h));

        return Math.Abs(EarthRadius * c);
    }

    private static double DegreesToRadians(double degrees) => degrees * Math.PI / 180;

    private const double TOLERANCE_METRES = 0.1;
}