﻿namespace Models;

public class OptimalRouteFinder
{
    public OptimalRouteFinder(double[,] distances, int startNode = 0)
    {
        this.distances = distances;
        this.n = distances.GetLength(0);
        this.startNode = startNode;
        this.memo = new double[n, 1 << n];
        this.path = new int[n, 1 << n];

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < (1 << n); j++)
            {
                memo[i, j] = -1;
                path[i, j] = -1;
            }
        }
    }

    public List<int> FindOptimalTour()
    {
        var mask = 1 << startNode;
        var minCost = TSP_DP(startNode, mask);

        return ReconstructPath(minCost);
    }

    private double TSP_DP(int currentNode, int mask)
    {
        if (mask == (1 << n) - 1)
        {
            return distances[currentNode, startNode];
        }

        if (memo[currentNode, mask] != -1)
        {
            return memo[currentNode, mask];
        }

        var minCost = double.MaxValue;
        var bestNextNode = -1;

        for (var nextNode = 0; nextNode < n; nextNode++)
        {
            if ((mask & (1 << nextNode)) == 0)
            {
                var newMask = mask | (1 << nextNode);
                var cost = distances[currentNode, nextNode] + TSP_DP(nextNode, newMask);

                if (cost < minCost)
                {
                    minCost = cost;
                    bestNextNode = nextNode;
                }
            }
        }

        memo[currentNode, mask] = minCost;
        path[currentNode, mask] = bestNextNode;

        return minCost;
    }

    private List<int> ReconstructPath(double minCost)
    {
        List<int> tour = new List<int>();
        int currentNode = startNode;
        int mask = 1 << startNode;

        tour.Add(startNode);

        for (int i = 1; i < n; i++)
        {
            int nextNode = path[currentNode, mask];
            tour.Add(nextNode);
            mask |= (1 << nextNode);
            currentNode = nextNode;
        }

        tour.Add(startNode);

        return tour;
    }

    private double[,] distances;
    private int n;
    private int startNode;
    private double[,] memo;
    private int[,] path;
}