﻿namespace Models;

public sealed record class CoordsRange
{
    public CoordPair Start { get; }

    public CoordPair End { get; }

    public CoordsRange(CoordPair start, CoordPair end)
    {
        if (start == end)
        {
            throw new ArgumentException("Start and end coordinates should differ.");
        }

        Start = start ?? throw new ArgumentNullException(nameof(start));
        End = end ?? throw new ArgumentNullException(nameof(end));
    }

    public double GetDistanceMetres()
    {
        return CoordPair.GetDistanceInMeters(Start, End);
    }
}