﻿using Models.Account;
using Models.Segments;

namespace Models.Requests;

public sealed class RecreatingRequest
{
    public Id<User> UserId { get; }

    public Id<Request> RequestId { get; }

    public IReadOnlyCollection<CreatingSegment> InitialSegments { get; }

    public RecreatingRequest(
        Id<User> userId,
        Id<Request> requestId,
        IReadOnlyCollection<CreatingSegment> initialSegments)
    {
        UserId = userId ?? throw new ArgumentNullException(nameof(userId));
        RequestId = requestId ?? throw new ArgumentNullException(nameof(requestId));

        ArgumentNullException.ThrowIfNull(initialSegments);

        if (initialSegments.Count == 0)
        {
            throw new ArgumentException("Initial segments count should be greater than 0.");
        }

        InitialSegments = initialSegments;
    }
}