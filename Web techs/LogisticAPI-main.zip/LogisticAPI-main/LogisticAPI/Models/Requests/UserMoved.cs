﻿using Models.Account;

namespace Models.Requests;

public sealed class UserMoved
{
    public Id<User> UserId { get; }

    public Id<Request> RequestId { get; }

    public CoordPair OldCoord { get; }

    public CoordPair NewCoord { get; }

    public UserMoved(
        Id<User> userId,
        Id<Request> requestId,
        CoordPair oldCoord,
        CoordPair newCoord)
    {
        UserId = userId ?? throw new ArgumentNullException(nameof(userId));
        RequestId = requestId ?? throw new ArgumentNullException(nameof(requestId));

        ArgumentNullException.ThrowIfNull(oldCoord);
        ArgumentNullException.ThrowIfNull(newCoord);

        if (oldCoord == newCoord)
        {
            throw new ArgumentException(
                "Coords for user movement should be different.");
        }

        OldCoord = oldCoord;
        NewCoord = newCoord;
    }
}
