﻿using System.ComponentModel;

namespace Models.Requests;

public sealed class ChangeRequestStatus
{
    public Id<Request> RequestId { get; }

    public RequestStatus OldStatus { get; }

    public RequestStatus NewStatus { get; }

    public ChangeRequestStatus(
        Id<Request> requestId,
        RequestStatus oldStatus,
        RequestStatus newStatus)
    {
        RequestId = requestId ?? throw new ArgumentNullException(nameof(requestId));

        if (!Enum.IsDefined(typeof(RequestStatus), oldStatus))
        {
            throw new InvalidEnumArgumentException(
                nameof(oldStatus),
                (int)oldStatus,
                typeof(RequestStatus));
        }

        if (!Enum.IsDefined(typeof(RequestStatus), newStatus))
        {
            throw new InvalidEnumArgumentException(
                nameof(newStatus),
                (int)newStatus,
                typeof(RequestStatus));
        }

        ValidateStatuses(oldStatus, newStatus);

        OldStatus = oldStatus;
        NewStatus = newStatus;
    }

    public void ValidateStatuses(RequestStatus oldStatus, RequestStatus newStatus)
    {
        if (oldStatus == newStatus)
        {
            return;
        }

        switch (oldStatus, newStatus)
        {
            case (RequestStatus.Created, RequestStatus.Accepted)
            or (RequestStatus.Created, RequestStatus.Closed)
            or (RequestStatus.Accepted, RequestStatus.Followed)
            or (RequestStatus.Accepted, RequestStatus.Closed)
            or (RequestStatus.Followed, RequestStatus.Unfollowed)
            or (RequestStatus.Unfollowed, RequestStatus.Followed)
            or (RequestStatus.Unfollowed, RequestStatus.Closed):

                return;

            default:
                throw new InvalidOperationException(
                    $"Can not change status from '{oldStatus}' to '{newStatus}'.");
        }
    }
}