﻿using System.ComponentModel;
using Models.Account;
using Models.Segments;

namespace Models.Requests;

public sealed class CreatingRequest
{
    public Id<User> UserId { get; }

    public Name<Request> Guid { get; }

    public CoordsRange CoordsRange { get; }

    public RequestType RequestType { get; }

    public IReadOnlyCollection<CreatingSegment> Segments { get; }

    public CreatingRequest(
        Id<User> userId, 
        Name<Request> guid,
        CoordsRange coordsRange,
        RequestType requestType,
        IReadOnlyCollection<CreatingSegment> segments)
    {
        UserId = userId ?? throw new ArgumentNullException(nameof(userId));
        Guid = guid ?? throw new ArgumentNullException(nameof(guid));
        CoordsRange = coordsRange 
            ?? throw new ArgumentNullException(nameof(coordsRange));

        ArgumentNullException.ThrowIfNull(segments);

        if (segments.Count == 0)
        {
            throw new ArgumentException("Segments count should be greater than zero.");
        }

        Segments = segments;

        if (!Enum.IsDefined(typeof(RequestType), requestType))
        {
            throw new InvalidEnumArgumentException(
                nameof(requestType),
                (int)requestType,
                typeof(RequestType));
        }

        RequestType = requestType;
    }
}