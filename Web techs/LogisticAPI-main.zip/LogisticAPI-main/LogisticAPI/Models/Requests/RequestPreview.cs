﻿using System.ComponentModel;

namespace Models.Requests;

public sealed class RequestPreview
{
    public Id<Request> RequestId { get; }

    public RequestStatus Status { get; }

    public RequestType RequestType { get; }

    public DateTimeOffset CreationDate { get; }

    public DateTimeOffset LastUpdate { get; }

    public RequestPreview(
        Id<Request> requestId,
        RequestStatus status,
        RequestType requestType,
        DateTimeOffset creationDate,
        DateTimeOffset lastUpdate)
    {
        RequestId = requestId ?? throw new ArgumentNullException(nameof(requestId));

        if (!Enum.IsDefined(typeof(RequestStatus), status))
        {
            throw new InvalidEnumArgumentException(
                nameof(status),
                (int)status,
                typeof(RequestStatus));
        }

        Status = status;

        if (!Enum.IsDefined(typeof(RequestType), requestType))
        {
            throw new InvalidEnumArgumentException(
                nameof(requestType),
                (int)requestType,
                typeof(RequestType));
        }

        RequestType = requestType;

        CreationDate = creationDate;
        LastUpdate = lastUpdate;
    }
}