﻿using Models.Segments;

namespace Models.Requests;

public sealed class CreatedRequest
{
    public Id<Request> RequestId { get; }

    public IReadOnlyCollection<CreatingSegment> InitialSegments { get; }

    public CreatedRequest(
        Id<Request> requestId,
        IReadOnlyCollection<CreatingSegment> initialSegments)
    {
        RequestId = requestId ?? throw new ArgumentNullException(nameof(requestId));

        ArgumentNullException.ThrowIfNull(initialSegments);

        if (initialSegments.Count == 0)
        {
            throw new ArgumentException("Initial segments count should be greater than 0.");
        }

        InitialSegments = initialSegments;
    }
}