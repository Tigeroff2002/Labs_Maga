﻿using MediatR;
using Models.Account;

namespace Models.Requests.Events;

public abstract class UserEventBase : INotification
{
    public Id<User> UserId { get; }

    public DateTimeOffset Timestamp { get; }

    protected UserEventBase(
        Id<User> userId,
        DateTimeOffset timestamp)
    {
        UserId = userId ?? throw new ArgumentNullException(nameof(userId));
        Timestamp = timestamp;
    }
}