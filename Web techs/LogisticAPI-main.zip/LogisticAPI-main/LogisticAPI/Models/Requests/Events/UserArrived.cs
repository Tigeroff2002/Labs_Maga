﻿using Models.Account;

namespace Models.Requests.Events;

public sealed class UserArrived : UserRequestEvent
{
    public UserArrived(
        Id<User> userId, 
        Id<Request> requestId,
        DateTimeOffset timestamp) 
        : base(userId, requestId, timestamp)
    {
    }
}