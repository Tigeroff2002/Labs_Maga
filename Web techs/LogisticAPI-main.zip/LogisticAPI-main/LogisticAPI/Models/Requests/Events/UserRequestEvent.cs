﻿using MediatR;
using Models.Account;

namespace Models.Requests.Events;

public abstract class UserRequestEvent : UserEventBase
{
    public Id<Request> RequestId { get; }

    protected UserRequestEvent(
        Id<User> userId,
        Id<Request> requestId,
        DateTimeOffset timestamp)
        : base(userId, timestamp)
    {
        RequestId = requestId 
            ?? throw new ArgumentNullException(nameof(requestId));
    }
}