﻿using System.ComponentModel;
using Models.Account;
using Models.Payments;

namespace Models.Requests.Events;

public sealed class PaymentStatusUpdated : UserEventBase
{
    public PaymentGUID PaymentGUID { get; }

    public PaymentStatus Status { get; }

    public PaymentStatusUpdated(
        Id<User> userId, 
        PaymentGUID paymentGUID,
        PaymentStatus status,
        DateTimeOffset timestamp) : base(userId, timestamp)
    {
        PaymentGUID = paymentGUID
            ?? throw new ArgumentNullException(nameof(paymentGUID));

        if (!Enum.IsDefined(typeof(PaymentStatus), status))
        {
            throw new InvalidEnumArgumentException(nameof(status));
        }

        Status = status;
    }
}