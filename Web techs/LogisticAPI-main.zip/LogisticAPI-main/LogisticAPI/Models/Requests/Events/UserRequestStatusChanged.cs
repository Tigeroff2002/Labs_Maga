﻿using Models.Account;

namespace Models.Requests.Events;

public sealed class UserRequestStatusChanged : UserRequestEvent
{
    public ChangeRequestStatus RequestStatusChange { get; }

    public UserRequestStatusChanged(
        Id<User> userId, 
        ChangeRequestStatus requestStatusChange,
        DateTimeOffset timestamp) 
        : base(
            userId, 
            requestStatusChange?.RequestId 
                ?? throw new ArgumentNullException(nameof(requestStatusChange)), 
            timestamp)
    {
        RequestStatusChange = requestStatusChange
            ?? throw new ArgumentNullException(nameof(requestStatusChange));
    }
}