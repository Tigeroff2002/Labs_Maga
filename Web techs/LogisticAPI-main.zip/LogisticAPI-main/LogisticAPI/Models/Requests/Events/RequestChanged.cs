﻿using Models.Account;

namespace Models.Requests.Events;

public sealed class RequestChanged : UserRequestEvent
{
    public Request RedrawedRequest { get; }

    public RequestChanged(
        Id<User> userId, 
        DateTimeOffset timestamp,
        Request redrawedRequest)
        : base(
            userId, 
            redrawedRequest?.Id
            ?? throw new ArgumentNullException(nameof(redrawedRequest)),
            timestamp)
    {
        ArgumentNullException.ThrowIfNull(redrawedRequest);

        RedrawedRequest = redrawedRequest;
    }
}