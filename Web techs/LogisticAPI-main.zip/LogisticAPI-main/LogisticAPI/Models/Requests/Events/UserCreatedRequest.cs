﻿using Models.Account;

namespace Models.Requests.Events;

public sealed class UserCreatedRequest : UserRequestEvent
{
    public UserCreatedRequest(
        Id<User> userId, 
        Id<Request> requestId,
        DateTimeOffset timestamp) 
        : base(userId, requestId, timestamp)
    {
    }
}