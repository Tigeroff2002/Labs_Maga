﻿using Models.Account;

namespace Models.Requests.Events;

public sealed class UserRecreatedRequest : UserRequestEvent
{
    public UserRecreatedRequest(
        Id<User> userId, 
        Id<Request> requestId, 
        DateTimeOffset timestamp) 
        : base(userId, requestId, timestamp)
    {
    }
}