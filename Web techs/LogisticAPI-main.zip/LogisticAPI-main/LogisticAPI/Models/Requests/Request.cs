﻿using System.ComponentModel;
using Models.Account;
using Models.Segments;

namespace Models.Requests;

public sealed class Request
{
    public Id<Request> Id { get; }

    public Id<User> UserId { get; }

    public CoordsRange CoordsRange { get; }

    public DateTimeOffset CreationDate { get; }

    public RequestStatus Status { get; }

    public RequestType RequestType { get; }

    public IReadOnlyCollection<Segment> Segments { get; }

    public Request(
        Id<Request> id, 
        Id<User> userId, 
        CoordsRange coordsRange, 
        RequestStatus status,
        RequestType requestType,
        IReadOnlyCollection<Segment> segments,
        DateTimeOffset creationDate)
    {
        Id = id ?? throw new ArgumentNullException(nameof(id));
        UserId = userId ?? throw new ArgumentNullException(nameof(userId));
        CoordsRange = coordsRange ?? throw new ArgumentNullException(nameof(coordsRange));

        if (!Enum.IsDefined(typeof(RequestStatus), status))
        {
            throw new InvalidEnumArgumentException(
                nameof(status),
                (int)status,
                typeof(RequestStatus));
        }

        Status = status;

        ArgumentNullException.ThrowIfNull(segments);

        if (segments.Count == 0)
        {
            throw new ArgumentException("Segments count should not be zero.");
        }

        Segments = segments;

        if (!Enum.IsDefined(typeof(RequestType), requestType))
        {
            throw new InvalidEnumArgumentException(
                nameof(requestType),
                (int)requestType,
                typeof(RequestType));
        }

        RequestType = requestType;

        CreationDate = creationDate;
    }
}