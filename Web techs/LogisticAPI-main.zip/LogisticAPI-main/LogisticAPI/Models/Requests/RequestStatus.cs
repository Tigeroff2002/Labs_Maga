﻿namespace Models.Requests;

public enum RequestStatus
{
    Created,

    Accepted,

    Followed,

    Unfollowed,

    Closed
}