﻿using Models.Account;
using Models.Payments;

namespace Models.Subscriptions;

public sealed class Subscription
{
    public Id<User> UserId { get; }

    public Id<Payment> PaymentId { get; }

    public DateTimeOffset StartDate { get; }

    public DateTimeOffset EndDate { get; }

    public Subscription(
        Id<User> userId,
        Id<Payment> paymentId,
        DateTimeOffset startDate,
        DateTimeOffset endDate)
    {
        UserId = userId ?? throw new ArgumentNullException(nameof(userId));
        PaymentId = paymentId ?? throw new ArgumentNullException(nameof(paymentId));

        ArgumentOutOfRangeException.ThrowIfLessThanOrEqual(endDate, startDate);
        StartDate = startDate;
        EndDate = endDate;
    }
}