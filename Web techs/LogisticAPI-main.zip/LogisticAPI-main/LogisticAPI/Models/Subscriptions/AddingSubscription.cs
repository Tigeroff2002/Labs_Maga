﻿using Models.Account;
using Models.Payments;

namespace Models.Subscriptions;

public sealed class AddingSubscription
{
    public Id<User> UserId { get; }

    public Id<Payment> PaymentId { get; }

    public TimeSpan Duration { get; }

    public AddingSubscription(
        Id<User> userId,
        Id<Payment> paymentId, 
        TimeSpan duration)
    {
        UserId = userId ?? throw new ArgumentNullException(nameof(userId));
        PaymentId = paymentId ?? throw new ArgumentNullException(nameof(paymentId));
        Duration = duration;
    }
}