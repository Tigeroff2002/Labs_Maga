﻿namespace Models;

public record class Id<TEntity>
{
    public long Value { get; }

    public Id(long value)
    {
        Value = value;
    }
}
