﻿namespace Models;

public sealed record class Coord
{
    public double Value { get; }

    public Coord(double value)
    {
        ArgumentOutOfRangeException.ThrowIfLessThanOrEqual(value, MIN);
        ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual(value, MAX);

        Value = value;
    }

    public const double MIN = 0;
    public const double MAX = 90;
}