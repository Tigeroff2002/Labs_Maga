﻿using System.ComponentModel;
using System.Net.Mail;
using Models.Subscriptions;

namespace Models.Account;

public sealed class UserProfileInfo
{
    public Id<User> Id { get; }

    public MailAddress Email { get; }

    public Subscription? Subscription { get; }

    public Role Role { get; }

    public UserProfileInfo(
        Id<User> id,
        MailAddress email,
        Role role, 
        Subscription? subscription = null)
    {
        ArgumentNullException.ThrowIfNull(id);
        Id = id;

        ArgumentNullException.ThrowIfNull(email);
        Email = email;

        if (!Enum.IsDefined(typeof(Role), role))
        {
            throw new InvalidEnumArgumentException(
                nameof(role),
                (int)role,
                typeof(Role));
        }
        Role = role;

        Subscription = subscription;
    }
}