﻿namespace Models.Account;

public sealed record class FullName
{
    public Name<User> FirstName { get; }

    public Name<User> SecondName { get; }

    public FullName(
        Name<User> firstName,
        Name<User> secondName)
    {
        FirstName = firstName;
        SecondName = secondName;
    }

    public override string ToString()
    {
        return $"{SecondName} {FirstName}";
    }
}