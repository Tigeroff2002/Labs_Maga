﻿namespace Models.Account;

public enum Role
{
    /// <summary>
    /// По умолчанию.
    /// </summary>
    User,

    Admin
}