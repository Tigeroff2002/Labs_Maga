﻿using System.Net.Mail;

namespace Models.Account;

/// <summary>
/// Регистрирующийся в системе пользователь.
/// </summary>
public sealed class RegisteringUser
{
    public MailAddress Email { get; }

    public Role Role { get; }

    public RegisteringUser(
        MailAddress email,
        bool isAdmin)
    {
        Email = email ?? throw new ArgumentNullException(nameof(email));

        Role = isAdmin ? Role.Admin : Role.User;
    }
}