﻿using System.ComponentModel;

namespace Models.Account;

public sealed class User
{
    public Id<User> Id { get; }

    public UserProfileInfo ProfileInfo { get; }

    public Role Role { get; }

    public User(
        Id<User> id,
        UserProfileInfo profileInfo,
        Role role)
    {
        Id = id ?? throw new ArgumentNullException(nameof(id));
        ProfileInfo = profileInfo ?? throw new ArgumentNullException(nameof(profileInfo));

        if (!Enum.IsDefined(role))
        {
            throw new InvalidEnumArgumentException(
                nameof(role),
                (int)role,
                typeof(Role));
        }
        Role = role;
    }
}