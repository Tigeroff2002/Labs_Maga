﻿using Abstractions.Services;
using LogisticAPI.Authentification.Configuration;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.JsonWebTokens;
using System.Net.Mail;
using System.Security.Claims;

namespace LogisticAPI.Authentification.UserExistense;

/// <summary>
/// Промежуточный обработчик авторизации, проверяющий наличие пользовательского профиля на портале.
/// </summary>
public class UserExistsAuthorizationHandler :
    AuthorizationHandler<UserExistsRequirement>
{
    public UserExistsAuthorizationHandler(
        IUserIdentityFacade userIdentityFacade,
        IUserService userService,
        IOptions<AdminConfiguration> adminOptions,
        ILogger<UserExistsAuthorizationHandler> logger)
    {
        ArgumentNullException.ThrowIfNull(userIdentityFacade);
        _userIdentityFacade = userIdentityFacade;

        ArgumentNullException.ThrowIfNull(userService);
        _userService = userService;

        ArgumentNullException.ThrowIfNull(adminOptions);
        _adminConfiguration = adminOptions.Value;

        ArgumentNullException.ThrowIfNull(logger);
        _logger = logger;
    }

    /// <inheritdoc/>
    protected override async Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        UserExistsRequirement requirement)
    {
        var userId = _userIdentityFacade.Id;

        if (userId is not null)
        {
            context.Succeed(requirement);

            return;
        }

        var email = context.User.FindFirstValue(JwtRegisteredClaimNames.Email);

        if (email is null)
        {
            return;
        }

        var mailAddress = new MailAddress(email);

        bool isAdmin;

        try
        {
            isAdmin = IsCurrentUserAdmin(context);
        }
        catch (InvalidOperationException ex)
        {
            context.Fail(new(this, ex.Message));

            return;
        }

        var userInfo = await _userService.FindUserProfileInfoByEmailAsync(
            mailAddress,
            CancellationToken.None);

        if (userInfo is null)
        {
            if (!requirement.NeedRegisterIfNotExists)
            {
                return;
            }

            userInfo = await _userService.RegisterNewUserAsync(
                new(mailAddress, isAdmin),
                CancellationToken.None);
        }

        _logger.LogInformation("Auth user email is: {Email}", userInfo.Email);

        _userIdentityFacade.SetUserProfileInfoToContext(userInfo);

        context.Succeed(requirement);
    }

    private bool IsCurrentUserAdmin(AuthorizationHandlerContext context)
    {
        if (context.User.FindFirstValue(JwtRegisteredClaimNames.Typ)
            == _adminConfiguration.AdminClaim)
        {
            if (context.User.FindFirstValue(JwtRegisteredClaimNames.UniqueName)
                != _adminConfiguration.Password)
            {
                _logger.LogWarning(NOT_CORRECT_ADMIN_PASSWORD_MESSAGE);

                throw new InvalidOperationException(NOT_CORRECT_ADMIN_PASSWORD_MESSAGE);
            }

            return true;
        }

        return false;
    }

    private readonly IUserIdentityFacade _userIdentityFacade;
    private readonly IUserService _userService;
    private readonly AdminConfiguration _adminConfiguration;
    private readonly ILogger<UserExistsAuthorizationHandler> _logger;

    private const string NOT_CORRECT_ADMIN_PASSWORD_MESSAGE = "Not correct password encoded to admin jwt.";
}