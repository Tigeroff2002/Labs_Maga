﻿using Microsoft.AspNetCore.Authorization;

namespace LogisticAPI.Authentification.UserExistense;

/// <summary>
/// Маркер-требование для <see cref="UserExistsAuthorizationHandler"/>.
/// </summary>
public readonly record struct UserExistsRequirement(
    bool NeedRegisterIfNotExists = false)
    : IAuthorizationRequirement;
