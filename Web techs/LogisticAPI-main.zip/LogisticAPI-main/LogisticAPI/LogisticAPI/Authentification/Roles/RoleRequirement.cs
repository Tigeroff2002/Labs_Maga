﻿using Microsoft.AspNetCore.Authorization;
using Models.Account;
using System.ComponentModel;

namespace LogisticAPI.Authentification.Roles;

/// <summary>
/// Требование для <see cref="Models.Account.Role"/>.
/// </summary>
public readonly record struct RoleRequirement : IAuthorizationRequirement
{
    public Role Role { get; }

    public RoleRequirement(Role role)
    {
        if (!Enum.IsDefined(role))
        {
            throw new InvalidEnumArgumentException(
                nameof(role),
                (int)role,
                typeof(Role));
        }

        Role = role;
    }
}