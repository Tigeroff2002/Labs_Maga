﻿using Abstractions.Services;
using Microsoft.AspNetCore.Authorization;
using Models.Account;
using Models;

namespace LogisticAPI.Authentification.Roles;

public sealed class RoleAuthorizationHandler :
    AuthorizationHandler<RoleRequirement>
{
    public RoleAuthorizationHandler(
        IUserIdentityFacade userIdentityFacade,
        IRolesService rolesService,
        ILogger<RoleAuthorizationHandler> logger)
    {
        _userIdentityFacade = userIdentityFacade
            ?? throw new ArgumentNullException(nameof(userIdentityFacade));
        _rolesService = rolesService
            ?? throw new ArgumentNullException(nameof(rolesService));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <inheritdoc/>
    protected override async Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        RoleRequirement requirement)
    {
        var userId = _userIdentityFacade.Id;

        if (userId is null)
        {
            _logger.LogWarning("No authentificated user found in context.");

            context.Fail();

            return;
        }

        var role = await GetUserRoleAsync(userId, CancellationToken.None);

        if (role == requirement.Role)
        {
            context.Succeed(requirement);
        }
    }

    private async Task<Role> GetUserRoleAsync(
        Id<User> userId,
        CancellationToken token)
    {
        var sessionUserRole = _userIdentityFacade.Role;

        if (sessionUserRole is not null)
        {
            return sessionUserRole.Value;
        }

        return await _rolesService.GetUserRoleAsync(
            userId,
            token);
    }

    private readonly IUserIdentityFacade _userIdentityFacade;
    private readonly IRolesService _rolesService;
    private readonly ILogger<RoleAuthorizationHandler> _logger;
}