﻿namespace LogisticAPI.Authentification;

/// <summary>
/// Содержит константы типов специфических клеймов.
/// </summary>
public struct ClaimTypes
{
    /// <summary>
    /// Клейм идентификатора пользователя.
    /// </summary>
    public const string USER_ID_CLAIM_NAME = "user_id";

    /// <summary>
    /// Клейм роли пользователя.
    /// </summary>
    public const string USER_ROLE = "role";
}