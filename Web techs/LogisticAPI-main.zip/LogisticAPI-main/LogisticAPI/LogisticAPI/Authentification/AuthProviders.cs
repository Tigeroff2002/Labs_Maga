﻿namespace LogisticAPI.Authentification;

public struct AuthProviders
{
    /// <summary>
    /// Google.
    /// </summary>
    public const string GOOGLE = "google";

    /// <summary>
    /// Yandex.
    /// </summary>
    public const string YANDEX = "yandex";
}
