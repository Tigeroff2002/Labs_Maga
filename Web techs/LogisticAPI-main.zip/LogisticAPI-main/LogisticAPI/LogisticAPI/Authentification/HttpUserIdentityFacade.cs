﻿using System.Security.Claims;
using Abstractions.Services;
using Models;
using Models.Account;

namespace LogisticAPI.Authentification;

/// <summary>
/// Фасад для получения информации об авторизованном пользователе.
/// </summary>
public sealed class HttpUserIdentityFacade : IUserIdentityFacade
{
    public Id<User>? Id =>
        _contextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.USER_ID_CLAIM_NAME) is { } value
            ? new(long.Parse(value))
            : null;

    public Role? Role =>
        _contextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.USER_ROLE) is { } value
            ? Enum.Parse<Role>(value)
            : null;

    public HttpUserIdentityFacade(IHttpContextAccessor contextAccessor)
    {
        ArgumentNullException.ThrowIfNull(contextAccessor);

        _contextAccessor = contextAccessor;
    }

    public void SetUserProfileInfoToContext(UserProfileInfo userInfo)
    {
        var context = _contextAccessor.HttpContext!;

        context.User.AddIdentity(new(
            [
                new Claim(
                    ClaimTypes.USER_ID_CLAIM_NAME,
                    userInfo.Id.Value.ToString()),

                new Claim(
                    ClaimTypes.USER_ROLE,
                    userInfo.Role.ToString())
            ]));
    }

    private readonly IHttpContextAccessor _contextAccessor;
}