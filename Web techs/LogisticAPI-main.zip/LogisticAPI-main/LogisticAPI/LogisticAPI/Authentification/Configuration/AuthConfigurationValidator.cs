﻿using Microsoft.Extensions.Options;

namespace LogisticAPI.Authentification.Configuration;

/// <summary>
/// Валидатор для <see cref="AuthConfiguration"/>.
/// </summary>
[OptionsValidator]
public sealed partial class AuthConfigurationValidator :
    IValidateOptions<AuthConfiguration>
{ }