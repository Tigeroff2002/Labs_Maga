﻿using System.ComponentModel.DataAnnotations;

namespace LogisticAPI.Authentification.Configuration;

public sealed class AdminConfiguration
{
    // "admin"
    [Required]
    public required string AdminClaim { get; init; }

    // "unique_name"
    [Required]
    public required string Password { get; init; }
}
