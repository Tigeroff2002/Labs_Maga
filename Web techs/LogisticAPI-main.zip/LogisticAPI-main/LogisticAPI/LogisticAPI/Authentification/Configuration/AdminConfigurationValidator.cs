﻿using Microsoft.Extensions.Options;

namespace LogisticAPI.Authentification.Configuration;

[OptionsValidator]
public sealed partial class AdminConfigurationValidator :
    IValidateOptions<AdminConfiguration>
{
}