﻿using Abstractions.Services;
using Logic.Services;
using Logic.Services.Configuration;
using LogisticAPI.Authentification;
using Microsoft.Extensions.Options;

namespace LogisticAPI.Registrations;

public static class Logic
{
    public static IServiceCollection AddLogic(
        this IServiceCollection services,
        IConfiguration configuration)
        => services
            .AddServices(configuration)
            .AddHandlers();

    private static IServiceCollection AddServices(
        this IServiceCollection services,
        IConfiguration configuration)
        => services
            .AddScoped<IUserService, UsersService>()
            .AddScoped<IRolesService, RolesService>()
            .AddScoped<IRequestsService, RequestsService>()
            .AddSingleton<IRoutesService, RoutesService>()
            .AddSingleton<IScopedRequestsService, ScopedRequestsService>()
            .AddScoped<IPaymentService, PaymentService>()
            .AddScoped<ISubscriptionService, SubscriptionService>()
            .Configure<PaymentConfiguration>(configuration.GetSection(nameof(PaymentConfiguration)))
            .AddSingleton<IValidateOptions<PaymentConfiguration>, PaymentConfigurationValidator>();

    private static IServiceCollection AddHandlers(
        this IServiceCollection services)
        => services
            .AddHttpContextAccessor()
            .AddSingleton<IUserIdentityFacade, HttpUserIdentityFacade>();
}