﻿namespace LogisticAPI.Registrations;

using LogisticAPI.Authentification;
using LogisticAPI.Authentification.Configuration;
using LogisticAPI.Authentification.Roles;
using LogisticAPI.Authentification.UserExistense;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.JsonWebTokens;

using Role = Models.Account.Role;

public static class Authentification
{
    public static IServiceCollection AddAuth(
            this IServiceCollection services,
            IConfiguration configuration)
            => services
                .AddScoped<IAuthorizationHandler, UserExistsAuthorizationHandler>()
                .AddScoped<IAuthorizationHandler, RoleAuthorizationHandler>()

                .AddAuthentication()
                .AddJwtBearer(AuthProviders.GOOGLE, opt =>
                {
                    var googleConfig =
                        configuration
                            .GetSection(nameof(AuthConfiguration))
                            .Get<AuthConfiguration>()
                            ?? throw new InvalidOperationException("Auth configuration is invalid.");

                    opt.TokenHandlers.Clear();

                    opt.TokenHandlers.Add(new JsonWebTokenHandler());

                    opt.TokenValidationParameters.ValidateIssuer = false;

                    opt.TokenValidationParameters.ValidIssuer = googleConfig.Issuer;

                    opt.TokenValidationParameters.ValidateAudience = googleConfig.ValidateAudience;

                    opt.TokenValidationParameters.ValidAudience = googleConfig.Audience;

                    opt.TokenValidationParameters.SignatureValidator =
                       (token, _) =>
                           //var payload = Google.Apis.Auth.GoogleJsonWebSignature.ValidateAsync(token).Result;
                           new JsonWebToken(token);

                    opt.Events = new Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerEvents
                    {
                        OnTokenValidated = async (context) =>
                        {
                            try
                            {
                                if (googleConfig.ValidateSignature)
                                {
                                    var payload = await Google.Apis.Auth.GoogleJsonWebSignature
                                        .ValidateAsync(((JsonWebToken)context.SecurityToken).EncodedToken);
                                }

                                context.Success();
                            }
                            catch (Google.Apis.Auth.InvalidJwtException ex)
                            {
                                context.Fail($"Invalid token: {ex.Message}.");
                            }
                        },
                        OnMessageReceived = context =>
                        {
                            if (context.Request.Headers.TryGetValue(
                                "Authorization",
                                out var authHeader))
                            {
                                var token = authHeader.ToString().Replace("Bearer ", "");
                                context.Token = token;
                            }
                            return Task.CompletedTask;
                        },
                        OnAuthenticationFailed = context => Task.CompletedTask
                    };
                })
                .Services

                .AddSingleton<IValidateOptions<AuthConfiguration>, AuthConfigurationValidator>()
                .AddOptionsWithValidateOnStart<AuthConfiguration>()
                .Bind(configuration.GetRequiredSection(nameof(AuthConfiguration)))
                .Services

                .AddAuthorizationBuilder()
                .AddDefaultPolicy(
                    Policies.DEFAULT_POLICY,
                    opt => opt
                        .AddRequirements(new UserExistsRequirement())
                        .AddAuthenticationSchemes([AuthProviders.GOOGLE]))
                .AddPolicy(
                    Policies.ALLOW_REGISTER_POLICY,
                    opt => opt
                        .AddRequirements(new UserExistsRequirement(NeedRegisterIfNotExists: true))
                        .AddAuthenticationSchemes([AuthProviders.GOOGLE]))
                .AddPolicy(
                    AuthProviders.GOOGLE,
                    opt => opt
                        .AddRequirements(new UserExistsRequirement())
                        .AddAuthenticationSchemes([AuthProviders.GOOGLE]))

                .AddPolicy(
                    Role.User.ToString(),
                        opt => opt.AddRequirements(new RoleRequirement(Role.User)))

                .AddPolicy(
                    Role.Admin.ToString(),
                        opt => opt.AddRequirements(new RoleRequirement(Role.Admin)))

                .Services

                .AddSingleton<IValidateOptions<AdminConfiguration>, AdminConfigurationValidator>()
                .AddOptionsWithValidateOnStart<AdminConfiguration>()
                .Bind(configuration.GetRequiredSection(nameof(AdminConfiguration)))

                .Services;
}