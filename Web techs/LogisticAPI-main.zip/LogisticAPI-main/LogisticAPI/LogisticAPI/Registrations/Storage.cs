﻿using Abstractions.Storage;
using Abstractions.Storage.Repositories;
using Microsoft.EntityFrameworkCore;
using Models;
using Models.Payments;
using Models.Requests;
using Models.Segments;
using Npgsql;
using Storage;
using Storage.Repositories;

namespace LogisticAPI.Registrations;

public static class Storage
{
    public static IServiceCollection AddStorage(
        this IServiceCollection services,
        IConfiguration configuration)
        => services
            .AddNpgsqlDataSource(
                configuration.GetConnectionString("DefaultConnection")!,
                builder => builder
                    .MapEnum<Models.Account.Role>()
                    .MapEnum<RequestStatus>()
                    .MapEnum<RequestType>()
                    .MapEnum<SegmentType>()
                    .MapEnum<PaymentStatus>())
            .AddDbContext<LogisticContext>(
                (provider, opt) => opt.UseNpgsql(
                    provider.GetRequiredService<NpgsqlDataSource>()))
            .AddScoped<ILogisticUnitOfWork, LogisticUnitOfWork>()
            .AddScoped<IRepositoryContext, RepositoryContext>()
            .AddRepositories();

    private static IServiceCollection AddRepositories(
        this IServiceCollection services)
        => services
            .AddScoped<IUsersRepository, UsersRepository>()
            .AddScoped<IRequestsRepository, RequestsRepository>()
            .AddScoped<IPaymentsRepository, PaymentsRepository>()
            .AddScoped<ISubscriptionsRepository, SubscriptionsRepository>();
}