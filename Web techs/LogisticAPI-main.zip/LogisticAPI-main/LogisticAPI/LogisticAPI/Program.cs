using LogisticAPI.Registrations;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using MediatR;
using Logic.Hubs;
using Logic.Notifications;

var builder = WebApplication.CreateBuilder(args);

builder.Services
    .AddControllers()
    .AddNewtonsoftJson(
        opt => opt.SerializerSettings.Converters.Add(
            new StringEnumConverter(new SnakeCaseNamingStrategy())));

builder.Services.AddHealthChecks();

builder.Services
    .AddCors(options => options
        .AddDefaultPolicy(builder => _ = builder
            .SetIsOriginAllowed(_ => true)
            .AllowAnyMethod()
            .AllowAnyHeader()
            .AllowCredentials()));

builder.Services
    .AddSwagger()
    .AddLogging()
    .AddLogic(builder.Configuration)
    .AddStorage(builder.Configuration)
    .AddAuth(builder.Configuration);

builder.Services.AddSignalR();

builder.Services.AddMediatR(typeof(RequestCreatedEventHandler).Assembly);

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    // app.UseSwagger().UseSwaggerUI();
}

app.UseSwagger().UseSwaggerUI();

app.UseCors();
app.UseHttpsRedirection();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.UseHealthChecks("/hc");

app.MapHub<LogisticHub>("/logistic");

app.Run();