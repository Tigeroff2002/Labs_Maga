﻿using Abstractions.Services;
using Contracts.Responses;
using Contracts.Responses.Account;
using LogisticAPI.Authentification;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LogisticAPI.Controllers;

[ApiController]
[Route("[controller]")]
[Produces("application/json")]
public sealed class UsersController : ControllerBase
{
    public UsersController(
        IUserService userService,
        IUserIdentityFacade userIdentityFacade,
        ILogger<UsersController> logger)
    {
        _userService = userService ?? throw new ArgumentNullException(nameof(userService));
        _userIdentityFacade = userIdentityFacade
            ?? throw new ArgumentNullException(nameof(userIdentityFacade));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Возвращает информацию о профиле авторизованного пользователя.
    /// </summary>
    /// <param name="token">
    /// Токен отмены.
    /// </param>
    /// <returns>
    /// <see cref="ActionResult{TValue}"/> с данными профиля пользователя.
    /// </returns>
    [Authorize(Policy = Policies.ALLOW_REGISTER_POLICY)]
    [HttpGet("me")]
    [ProducesResponseType<UserProfileInfoResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<FailureCommandResultResponse>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<UserProfileInfoResponse>> MeAsync(CancellationToken token)
    {
        _logger.LogInformation("Getting info by user id: {Id}", _userIdentityFacade.Id!.Value);

        try
        {
            var profileInfo = await _userService.GetUserProfileInfoAsync(_userIdentityFacade.Id, token);

            return Ok(UserProfileInfoResponse.FromDomain(profileInfo));
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(FailureCommandResultResponse.FromException(ex));
        }
    }

    /// <summary>
    /// Возвращает информацию о профиле запрашиваемого пользователя.
    /// </summary>
    /// <param name="userId">
    /// Идентификатор пользователя.
    /// </param>
    /// <param name="token">
    /// Токен отмены.
    /// </param>
    /// <returns>
    /// <see cref="ActionResult{TValue}"/> с данными профиля пользователя.
    /// </returns>
    /// <response code="400">
    /// Когда пользователя с таким идентификатором не удалось найти.
    /// </response>
    [AllowAnonymous]
    [HttpGet("{userId}")]
    [ProducesResponseType<UserProfileInfoResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<FailureCommandResultResponse>(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<UserProfileInfoResponse>> GetUserByIdAsync(
        [FromRoute] long userId,
        CancellationToken token)
    {
        _logger.LogInformation("Getting info by user id: {Id}", userId);

        try
        {
            var profileInfo = await _userService.GetUserProfileInfoAsync(new(userId), token);

            return Ok(UserProfileInfoResponse.FromDomain(profileInfo));
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(FailureCommandResultResponse.FromException(ex));
        }
    }

    private readonly IUserService _userService;
    private readonly IUserIdentityFacade _userIdentityFacade;
    private readonly ILogger<UsersController> _logger;
}