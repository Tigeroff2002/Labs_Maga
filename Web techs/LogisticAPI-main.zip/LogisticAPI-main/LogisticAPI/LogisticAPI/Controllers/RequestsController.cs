﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using Abstractions.Services;
using Contracts.Events.Backend;
using Contracts.Requests;
using Contracts.Responses;
using Contracts.Responses.Requests;
using Contracts.Responses.Segments;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Models;

namespace LogisticAPI.Controllers;

[ApiController]
[Route("[controller]")]
[Produces("application/json")]
[Authorize]
public sealed class RequestsController : ControllerBase
{
    public RequestsController(
        ILogger<RequestsController> logger,
        IRequestsService service,
        IUserIdentityFacade userIdentityFacade)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _service = service ?? throw new ArgumentNullException(nameof(service));
        _userIdentityFacade = userIdentityFacade
            ?? throw new ArgumentNullException(nameof(userIdentityFacade));
    }

    [HttpPost]
    [ProducesResponseType<CreatedRequestIdResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<FailureCommandResultResponse>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [Route("create/simple")]
    public async Task<IActionResult> CreateSimpleRequestAsync(
        [Required][NotNull] CreateSimpleRequestDTO createParams,
        CancellationToken token)
    {
        token.ThrowIfCancellationRequested();

        _logger.LogDebug("Start processing creating new simple request");

        try
        {
            var requestId = await _service.CreateSimpleRequestAsync(
                new(createParams.Guid),
                new(
                    new(
                        new(createParams.CoordsRange.StartCoord.Width),
                        new(createParams.CoordsRange.StartCoord.Heigth)),
                    new(
                        new(createParams.CoordsRange.EndCoord.Width),
                        new(createParams.CoordsRange.EndCoord.Heigth))),
                token);

            _logger.LogInformation(
                "New simple request {RequestId} has been created",
                requestId.Value);

            return Ok(new CreatedRequestIdResponse
            {
                RequestId = requestId.Value
            });
        }
        catch (Exception ex)
        when (ex is InvalidOperationException or ArgumentException)
        {
            _logger.LogError("Error is happened: '{Message}'", ex.Message);

            return BadRequest(FailureCommandResultResponse.FromException(ex));
        }
    }

    [HttpPost]
    [ProducesResponseType<CreatedRequestIdResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<FailureCommandResultResponse>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [Route("create/salesman")]
    public async Task<IActionResult> CreateTravellingSalesmanRequestAsync(
        [Required][NotNull] CreateSalesmanRequestDTO createParams,
        CancellationToken token)
    {
        token.ThrowIfCancellationRequested();

        _logger.LogDebug("Start processing creating new travelling salesman request");

        try
        {
            var requestId = await _service.CreateTravellingSalesmanRequestAsync(
                new(createParams.Guid),
                new(
                    new(
                        new(createParams.StartCoord.Width),
                        new(createParams.StartCoord.Heigth)),
                    createParams.ToBeVisitedCoords
                        .Select(c => new CoordPair(
                            new(c.Width), 
                            new(c.Heigth)))
                        .ToHashSet()),
                token);

            _logger.LogInformation(
                "New travelling salesman request {RequestId} has been created",
                requestId.Value);

            return Ok(new CreatedRequestIdResponse
            {
                RequestId = requestId.Value
            });
        }
        catch (Exception ex)
        when (ex is InvalidOperationException or ArgumentException)
        {
            _logger.LogError("Error is happened: '{Message}'", ex.Message);

            return BadRequest(FailureCommandResultResponse.FromException(ex));
        }
    }

    [HttpPatch]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType<FailureCommandResultResponse>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [Route("recreate")]
    public async Task<IActionResult> RecreateRequestAsync(
        [Required][FromQuery] long requestId,
        CancellationToken token)
    {
        token.ThrowIfCancellationRequested();

        _logger.LogDebug("Start processing recreating request {RequestId}", requestId);

        try
        {
            await _service.RecreateRequestAsync(
                new(requestId),
                token);

            _logger.LogInformation(
                "Request {RequestId} has been recreated",
                requestId);

            return Ok();
        }
        catch (Exception ex)
        when (ex is InvalidOperationException or ArgumentException)
        {
            _logger.LogError("Error is happened: '{Message}'", ex.Message);

            return BadRequest(FailureCommandResultResponse.FromException(ex));
        }
    }

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType<FailureCommandResultResponse>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [Route("change_status")]
    public async Task<IActionResult> ChangeRequestStatusAsync(
        [Required][NotNull] ChangeRequestStatusDTO changeStatusParamgs,
        CancellationToken token)
    {
        token.ThrowIfCancellationRequested();

        _logger.LogDebug(
            "Start processing changing request {RequestId} status",
            changeStatusParamgs.RequestId);

        try
        {
            await _service.ChangeRequestStatusAsync(
                new(changeStatusParamgs.RequestId),
                changeStatusParamgs.NewStatus,
                token);

            return Ok();
        }
        catch (Exception ex)
        when (ex is InvalidOperationException or ArgumentException)
        {
            _logger.LogError("Error is happened: '{Message}'", ex.Message);

            return BadRequest(FailureCommandResultResponse.FromException(ex));
        }
    }

    [HttpGet]
    [ProducesResponseType<GetUserRequestResultResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<FailureCommandResultResponse>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> GetRequestDataByIdAsync(
        [Required][FromQuery] long requestId,
        [Required][FromQuery] bool isActive,
        CancellationToken token)
    {
        token.ThrowIfCancellationRequested();

        _logger.LogDebug(
            "Start processing getting request {RequestId} data",
            requestId);

        try
        {
            var requestData = await _service.GetRequestByIdAsync(
                new(requestId),
                token);

            _logger.LogInformation(
                "Request {RequestId} data has been received",
                requestId);

            var segments = requestData.Segments.Select(s => new SegmentDTO
            {
                Id = s.Id.Value,
                SegmentType = s.SegmentType,
                Number = s.Number.Value,
                CoordsRange = new()
                {
                    StartCoord = new()
                    {
                        Width = s.CoordsRange.Start.Width.Value,
                        Heigth = s.CoordsRange.Start.Height.Value
                    },
                    EndCoord = new()
                    {
                        Width = s.CoordsRange.End.Width.Value,
                        Heigth = s.CoordsRange.End.Height.Value
                    }
                },
                Length = s.Length.Value
            }).ToList();

            return Ok(new GetUserRequestResultResponse
            {
                RequestId = requestId,
                RequestStatus = requestData.Status,
                RequestType = requestData.RequestType,
                CreationDate = requestData.CreationDate,
                CoordsRange = new()
                {
                    StartCoord = new()
                    {
                        Width = requestData.CoordsRange.Start.Width.Value,
                        Heigth = requestData.CoordsRange.Start.Height.Value
                    },
                    EndCoord = new()
                    {
                        Width = requestData.CoordsRange.End.Width.Value,
                        Heigth = requestData.CoordsRange.End.Height.Value
                    }
                },
                InitialSegments = segments,
                ActiveSegments = isActive ? segments : []
            });
        }
        catch (Exception ex)
        when (ex is InvalidOperationException or ArgumentException)
        {
            _logger.LogError("Error is happened: '{Message}'", ex.Message);

            return BadRequest(FailureCommandResultResponse.FromException(ex));
        }
    }

    [HttpGet]
    [ProducesResponseType<GetAllUserRequestsResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<FailureCommandResultResponse>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [Route("all")]
    public async Task<IActionResult> GetRequestPreviewsForUserAsync(
        CancellationToken token)
    {
        token.ThrowIfCancellationRequested();

        _logger.LogDebug("Start processing getting all user requests previews");

        try
        {
            var requestPreviews = await _service.GetAllUserRequestsPreviewsAsync(token);

            _logger.LogInformation(
                "Completing request with getting all user request previews");

            return Ok(new GetAllUserRequestsResponse
            {
                RequestsPreviews = requestPreviews.Select(pr => new RequestPreviewDTO
                {
                    RequestId = pr.RequestId.Value,
                    Status = pr.Status,
                    RequestType = pr.RequestType,
                    CreationDate = pr.CreationDate,
                    LastUpdate = pr.LastUpdate,
                }).ToList()
            });
        }
        catch (Exception ex)
        when (ex is InvalidOperationException or ArgumentException)
        {
            _logger.LogError("Error is happened: '{Message}'", ex.Message);

            return BadRequest(FailureCommandResultResponse.FromException(ex));
        }
    }

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType<FailureCommandResultResponse>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [Route("move_user")]
    public async Task<IActionResult> ChangeUserPlacementCommandAsync(
        [Required][NotNull] UserMovedRequest movedDto,
        CancellationToken token)
    {
        token.ThrowIfCancellationRequested();

        _logger.LogDebug(
            "Start processing changing user placement" +
            "on request {RequestId} command",
            movedDto.RequestId);

        try
        {
            await _service.ProcessUserMovementAsync(
                new(
                    _userIdentityFacade.Id!,
                    new(movedDto.RequestId),
                    new(new(movedDto.OldCoord.Width), new(movedDto.OldCoord.Heigth)),
                    new(new(movedDto.NewCoord.Width), new(movedDto.NewCoord.Heigth))),
                token);

            return Ok();
        }
        catch (Exception ex)
        when (ex is InvalidOperationException or ArgumentException)
        {
            _logger.LogError("Error is happened: '{Message}'", ex.Message);

            return BadRequest(FailureCommandResultResponse.FromException(ex));
        }
    }

    private readonly IUserIdentityFacade _userIdentityFacade;
    private readonly ILogger<RequestsController> _logger;
    private readonly IRequestsService _service;
}