﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using Abstractions.Services;
using Contracts.Requests;
using Contracts.Responses;
using Contracts.Responses.Payments;
using Contracts.YooIntegration;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Models.Payments;

namespace LogisticAPI.Controllers;

[ApiController]
[Route("[controller]")]
[Produces("application/json")]
[Authorize]
public sealed class PaymentsController : ControllerBase
{
    public PaymentsController(
        IPaymentService paymentService,
        IUserIdentityFacade userIdentityFacade,
        ILogger<PaymentsController> logger)
    {
        _paymentService = paymentService
            ?? throw new ArgumentNullException(nameof(paymentService));
        _userIdentityFacade = userIdentityFacade
            ?? throw new ArgumentNullException(nameof(userIdentityFacade));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    [HttpPost]
    [ProducesResponseType<CreatePaymentResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<FailureCommandResultResponse>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [Route("create")]
    public async Task<IActionResult> CreatePayment(
        [Required][NotNull] CreatePaymentRequestDTO request,
        CancellationToken token)
    {
        try
        {
            var paymentCreated =
                await _paymentService.CreatePaymentAsync(
                    new(
                        _userIdentityFacade.Id!, 
                        new(request.Amount), 
                        new(Guid.NewGuid().ToString())),
                    token);

            return Ok(
                new CreatePaymentResponse
                {
                    PaymentId = paymentCreated.PaymentGuid.Value,
                    PaymentUrl = paymentCreated.PaymentUrl,
                    Timestamp = DateTimeOffset.UtcNow
                });
        }
        catch (Exception ex)
        when (ex is InvalidOperationException or ArgumentException)
        {
            _logger.LogError("Error is happened: '{Message}'", ex.Message);

            return BadRequest(FailureCommandResultResponse.FromException(ex));
        }
    }

    [HttpPost("yookassa-webhook")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType<FailureCommandResultResponse>(StatusCodes.Status400BadRequest)]
    [AllowAnonymous]
    public async Task<IActionResult> HandleYooWebhookAsync(
        [Required][NotNull] YooWebhookNotification notification,
        CancellationToken token)
    {
        try
        {
            var paymentId = notification.Object.PaymentId;

            await _paymentService.HandlePaymentUpdateAsync(
                new(paymentId),
                notification.Object.Status,
                token);

            return Ok();
        }
        catch (Exception ex)
        when (ex is InvalidOperationException or ArgumentException)
        {
            _logger.LogError("Error is happened: '{Message}'", ex.Message);

            return BadRequest(FailureCommandResultResponse.FromException(ex));
        }
    }

    [HttpGet("verify")]
    [ProducesResponseType<VerifyPaymentResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<FailureCommandResultResponse>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> VerifyPaymentAsync(
        [Required][FromQuery] string paymentGuid,
        CancellationToken token)
    {
        try
        {
            var status = await _paymentService.VerifyStatusPaymentAsync(
                new(paymentGuid),
                token);

            return Ok(new VerifyPaymentResponse
            {
                IsSucceeded = status == PaymentStatus.Succeeded,
                Status = status
            });
        }
        catch (Exception ex)
        when (ex is InvalidOperationException or ArgumentException)
        {
            _logger.LogError("Error is happened: '{Message}'", ex.Message);

            return BadRequest(FailureCommandResultResponse.FromException(ex));
        }
    }

    private readonly IPaymentService _paymentService;
    private readonly IUserIdentityFacade _userIdentityFacade;
    private readonly ILogger _logger;
}