﻿using Abstractions.Services;
using Contracts.Responses.Requests;
using Contracts.Responses;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Contracts.Responses.Subscriptions;

namespace LogisticAPI.Controllers;

[ApiController]
[Route("[controller]")]
[Produces("application/json")]
[Authorize]
public sealed class SubscriptionsController : ControllerBase
{
    public SubscriptionsController(
        ISubscriptionService service,
        IUserIdentityFacade userIdentityFacade,
        ILogger<SubscriptionsController> logger)
    {
        _subscriptionService = service 
            ?? throw new ArgumentNullException(nameof(service));
        _userIdentityFacade = userIdentityFacade
            ?? throw new ArgumentNullException(nameof(userIdentityFacade));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    [HttpGet]
    [ProducesResponseType<GetUserActiveSubscriptionResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<FailureCommandResultResponse>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [Route("all")]
    public async Task<IActionResult> GetSubscriptionForUserAsync(
        CancellationToken token)
    {
        token.ThrowIfCancellationRequested();

        _logger.LogDebug("Start processing get active subscription");

        try
        {
            var userId = _userIdentityFacade.Id!;

            var subscription =
                await _subscriptionService.FindActiveUserSubcriptionAsync(
                    userId,
                    token);

            _logger.LogInformation(
                "Completing getting active user {UserId} subscription", 
                userId.Value);

            return Ok(new GetUserActiveSubscriptionResponse
            {
                Subscription = subscription is null
                    ? null
                    : new()
                    {
                        PaymentId = subscription.PaymentId.Value,
                        StartDate = subscription.StartDate,
                        EndDate = subscription.EndDate
                    },
            });
        }
        catch (Exception ex)
        when (ex is InvalidOperationException or ArgumentException)
        {
            _logger.LogError("Error is happened: '{Message}'", ex.Message);

            return BadRequest(FailureCommandResultResponse.FromException(ex));
        }
    }

    private readonly ISubscriptionService _subscriptionService;
    private readonly IUserIdentityFacade _userIdentityFacade;
    private readonly ILogger _logger;
}