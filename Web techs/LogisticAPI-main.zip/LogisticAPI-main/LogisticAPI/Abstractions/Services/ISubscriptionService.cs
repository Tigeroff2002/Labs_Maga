﻿using Models;
using Models.Account;
using Models.Subscriptions;

namespace Abstractions.Services;

public interface ISubscriptionService
{
    Task<Subscription?> FindActiveUserSubcriptionAsync(
        Id<User> userId, 
        CancellationToken token);
}