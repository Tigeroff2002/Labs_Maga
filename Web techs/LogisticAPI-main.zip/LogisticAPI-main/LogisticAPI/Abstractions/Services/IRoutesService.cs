﻿using Models;
using Models.Segments;

namespace Abstractions.Services;

public interface IRoutesService
{
    public Task<CreatedDistanse> GenerateSegmentsAsync(
        CoordsRange coordsRange,
        CancellationToken token);
}