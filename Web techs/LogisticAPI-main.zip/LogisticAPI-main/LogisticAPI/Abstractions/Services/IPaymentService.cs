﻿using Models;
using Models.Payments;

namespace Abstractions.Services;

public interface IPaymentService
{
    Task<PaymentCreated> CreatePaymentAsync(
        PaymentRequest request,
        CancellationToken token);

    Task HandlePaymentUpdateAsync(
        PaymentGUID paymentGUID, 
        string status, 
        CancellationToken token);

    Task<PaymentStatus> VerifyStatusPaymentAsync(
        PaymentGUID paymentGUID,
        CancellationToken token);
}