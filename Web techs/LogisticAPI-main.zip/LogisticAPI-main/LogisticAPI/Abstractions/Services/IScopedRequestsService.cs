﻿using Models;
using Models.Requests;

namespace Abstractions.Services;

public interface IScopedRequestsService
{
    public Task ChangeRequestStatusAsync(
        Id<Request> requestId,
        RequestStatus newStatus,
        CancellationToken token);

    public Task ProcessUserMovementAsync(
        UserMoved userMoved,
        CancellationToken token);
}
