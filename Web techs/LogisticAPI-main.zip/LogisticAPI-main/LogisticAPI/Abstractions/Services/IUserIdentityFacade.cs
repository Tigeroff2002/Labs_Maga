﻿using Models;
using Models.Account;

namespace Abstractions.Services;

/// <summary>
/// Фасад для получения информации о пользователе, делающего запрос.
/// </summary>
public interface IUserIdentityFacade
{
    public Id<User>? Id { get; }

    public Role? Role { get; }

    public void SetUserProfileInfoToContext(UserProfileInfo userInfo);
}