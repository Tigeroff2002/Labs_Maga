﻿using Models.Account;
using Models;

namespace Abstractions.Services;

public interface IRolesService
{
    /// <summary>
    /// Получает роль для пользователя по его идентификатору.
    /// </summary>
    /// <param name="userId">
    /// Идентификатор пользователя.
    /// </param>
    /// <param name="token">
    /// Токен отмены.
    /// </param>
    /// <returns>
    /// <exception cref="ArgumentNullException">
    /// Если <paramref name="userId"/> равен <see langword="null"/>.
    /// </exception>
    /// <exception cref="InvalidOperationException">
    /// Если пользователя с идентификатором <paramref name="userId"/> не существует.
    /// </exception>
    Task<Role> GetUserRoleAsync(
        Id<User> userId, 
        CancellationToken token);
}