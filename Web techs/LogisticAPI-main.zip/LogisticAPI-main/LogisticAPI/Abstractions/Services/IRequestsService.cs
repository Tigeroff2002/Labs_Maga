﻿using Models;
using Models.Requests;

namespace Abstractions.Services;

public interface IRequestsService : IScopedRequestsService
{
    public Task<Id<Request>> CreateSimpleRequestAsync(
        Name<Request> requestGuid,
        CoordsRange coordsRange,
        CancellationToken token);

    public Task<Id<Request>> CreateTravellingSalesmanRequestAsync(
        Name<Request> requestGuid,
        TravellingSalesmanCoords coordsModel,
        CancellationToken token);

    public Task RecreateRequestAsync(
        Id<Request> requestId,
        CancellationToken token);

    public Task<Request> GetRequestByIdAsync(
        Id<Request> requestId,
        CancellationToken token);

    public Task<IReadOnlyCollection<RequestPreview>> GetAllUserRequestsPreviewsAsync(
        CancellationToken token);
}