﻿using Models;
using Models.Payments;

namespace Abstractions.Storage.Repositories;

public interface IPaymentsRepository
{
    Task AddPaymentTransactionAsync(
        PaymentRequest paymentRequest, 
        CancellationToken token);

    Task<Payment> GetPaymentByGuidAsync(
        PaymentGUID paymentGuid, 
        CancellationToken token);

    Task UpdatePaymentStatusAsync(
        PaymentGUID paymentGuid, 
        PaymentStatus newStatus,
        CancellationToken token);
}