﻿using Models;
using Models.Account;
using Models.Subscriptions;

namespace Abstractions.Storage.Repositories;

public interface ISubscriptionsRepository
{
    Task AddSubscriptionAsync(
        AddingSubscription subscription, 
        CancellationToken token);

    Task<Subscription?> FindActiveUserSubscriptionAsync(
        Id<User> userId,
        CancellationToken token);
}