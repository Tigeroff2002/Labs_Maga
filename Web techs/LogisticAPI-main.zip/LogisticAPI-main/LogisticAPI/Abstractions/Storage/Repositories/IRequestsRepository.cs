﻿using Models;
using Models.Account;
using Models.Requests;
using Models.Segments;

namespace Abstractions.Storage.Repositories;

public interface IRequestsRepository
{
    public Task CreateRequestAsync(
        CreatingRequest request,
        CancellationToken token);

    public Task UpdateRequestActiveSegments(
        Id<Request> requestId,
        IReadOnlyCollection<CreatingSegment> activeSegments,
        CancellationToken token);

    public Task RecreateRequestAsync(
        RecreatingRequest request,
        CancellationToken token);

    public Task ChangeRequestStatusAsync(
        ChangeRequestStatus changeModel,
        CancellationToken token);

    public Task<Request> GetRequestByIdAsync(
        Id<Request> requestId,
        CancellationToken token);

    public Task<Id<Request>> GetRequestIdByGuidAsync(
        Name<Request> requestGuid,
        CancellationToken token);

    public Task<bool> IsRequestRelatedToMe(
        Id<Request> requestId,
        Id<User> userId,
        CancellationToken token);

    public Task<IReadOnlyCollection<RequestPreview>> GetAllUserRequestsPreviewsAsync(
        Id<User> userId,
        CancellationToken token);
}