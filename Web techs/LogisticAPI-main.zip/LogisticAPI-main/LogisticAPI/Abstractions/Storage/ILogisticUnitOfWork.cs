﻿using Abstractions.Storage.Repositories;

namespace Abstractions.Storage;

public interface ILogisticUnitOfWork :
    IAsyncDisposable
{
    public IUsersRepository Users { get; }

    public IRequestsRepository Requests { get; }

    public IPaymentsRepository Payments { get; }

    public ISubscriptionsRepository Subscriptions { get; }

    public Task SaveAsync(CancellationToken token);
}